"! Business error returned to the caller as {"status":"ERROR","message":...}.
"! Write messages that tell the LLM how to fix its next call.
CLASS zcx_mcp_error DEFINITION PUBLIC INHERITING FROM cx_static_check CREATE PUBLIC.
  PUBLIC SECTION.
    DATA mv_text TYPE string READ-ONLY.
    METHODS constructor
      IMPORTING iv_text  TYPE string OPTIONAL
                previous TYPE REF TO cx_root OPTIONAL.
ENDCLASS.

CLASS zcx_mcp_error IMPLEMENTATION.
  METHOD constructor.
    super->constructor( previous = previous ).
    mv_text = iv_text.
  ENDMETHOD.
ENDCLASS.
