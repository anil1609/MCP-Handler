"! Minimal JSON writer used for all responses, plus a helper to cut a raw
"! JSON object out of a request body (used for BAPI "params").
CLASS zcl_mcp_json DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    CLASS-METHODS escape
      IMPORTING iv_text        TYPE csequence
      RETURNING VALUE(rv_text) TYPE string.
    CLASS-METHODS str
      IMPORTING iv_text        TYPE csequence
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS num
      IMPORTING iv_number      TYPE i
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS bool
      IMPORTING iv_flag        TYPE abap_bool
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS pair
      IMPORTING iv_key         TYPE csequence
                iv_raw         TYPE csequence
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS object
      IMPORTING it_pairs       TYPE string_table
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS array
      IMPORTING it_items       TYPE string_table
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS str_array
      IMPORTING it_items       TYPE string_table
      RETURNING VALUE(rv_json) TYPE string.
    "! Returns the raw JSON object value of a key, e.g. "params":{...}; empty if absent
    CLASS-METHODS extract_object
      IMPORTING iv_json        TYPE string
                iv_key         TYPE csequence
      RETURNING VALUE(rv_json) TYPE string.
ENDCLASS.

CLASS zcl_mcp_json IMPLEMENTATION.

  METHOD escape.
    rv_text = iv_text.
    REPLACE ALL OCCURRENCES OF `\` IN rv_text WITH `\\`.
    REPLACE ALL OCCURRENCES OF `"` IN rv_text WITH `\"`.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>cr_lf IN rv_text WITH `\n`.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline IN rv_text WITH `\n`.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN rv_text WITH `\t`.
  ENDMETHOD.

  METHOD str.
    rv_json = |"{ escape( iv_text ) }"|.
  ENDMETHOD.

  METHOD num.
    rv_json = |{ iv_number }|.
  ENDMETHOD.

  METHOD bool.
    rv_json = COND #( WHEN iv_flag = abap_true THEN `true` ELSE `false` ).
  ENDMETHOD.

  METHOD pair.
    rv_json = |"{ iv_key }":{ iv_raw }|.
  ENDMETHOD.

  METHOD object.
    rv_json = |\{{ concat_lines_of( table = it_pairs sep = `,` ) }\}|.
  ENDMETHOD.

  METHOD array.
    rv_json = |[{ concat_lines_of( table = it_items sep = `,` ) }]|.
  ENDMETHOD.

  METHOD str_array.
    DATA lt_items TYPE string_table.
    LOOP AT it_items INTO DATA(lv_item).
      APPEND str( lv_item ) TO lt_items.
    ENDLOOP.
    rv_json = array( lt_items ).
  ENDMETHOD.

  METHOD extract_object.
    DATA lv_depth     TYPE i.
    DATA lv_in_string TYPE abap_bool.
    DATA lv_escaped   TYPE abap_bool.

    DATA(lv_key) = |"{ iv_key }"|.
    DATA(lv_key_pos) = find( val = iv_json sub = lv_key case = abap_false ).
    IF lv_key_pos < 0.
      RETURN.
    ENDIF.
    DATA(lv_after_key) = lv_key_pos + strlen( lv_key ).
    DATA(lv_start) = find( val = iv_json sub = `{` off = lv_after_key ).
    IF lv_start < 0.
      RETURN.
    ENDIF.
    " only ':' and blanks may sit between the key and the opening brace
    DATA(lv_between) = substring( val = iv_json off = lv_after_key len = lv_start - lv_after_key ).
    CONDENSE lv_between NO-GAPS.
    IF lv_between <> `:`.
      RETURN.
    ENDIF.

    DATA(lv_len) = strlen( iv_json ).
    DATA(lv_i) = lv_start.
    WHILE lv_i < lv_len.
      DATA(lv_char) = substring( val = iv_json off = lv_i len = 1 ).
      IF lv_in_string = abap_true.
        IF lv_escaped = abap_true.
          lv_escaped = abap_false.
        ELSEIF lv_char = `\`.
          lv_escaped = abap_true.
        ELSEIF lv_char = `"`.
          lv_in_string = abap_false.
        ENDIF.
      ELSE.
        CASE lv_char.
          WHEN `"`.
            lv_in_string = abap_true.
          WHEN `{`.
            lv_depth = lv_depth + 1.
          WHEN `}`.
            lv_depth = lv_depth - 1.
            IF lv_depth = 0.
              rv_json = substring( val = iv_json off = lv_start len = lv_i - lv_start + 1 ).
              RETURN.
            ENDIF.
        ENDCASE.
      ENDIF.
      lv_i = lv_i + 1.
    ENDWHILE.
  ENDMETHOD.

ENDCLASS.
