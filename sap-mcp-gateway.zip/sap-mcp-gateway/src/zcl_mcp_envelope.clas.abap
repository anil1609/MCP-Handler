"! Builds the response envelope parts: columns, rows (arrays in column order), cells.
"! Dates are returned as YYYY-MM-DD, times as HH:MM:SS, conversion exits applied (ALPHA etc.).
CLASS zcl_mcp_envelope DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    CLASS-METHODS error
      IMPORTING iv_message     TYPE csequence
                iv_action      TYPE csequence OPTIONAL
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS columns
      IMPORTING it_cols        TYPE zif_mcp_types=>tt_col
      RETURNING VALUE(rv_json) TYPE string.
    "! iv_max = 0 -> all rows
    CLASS-METHODS rows
      IMPORTING it_data        TYPE ANY TABLE
                it_cols        TYPE zif_mcp_types=>tt_col
                iv_max         TYPE i DEFAULT 0
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS cell
      IMPORTING iv_value       TYPE any
                is_col         TYPE zif_mcp_types=>ty_col
      RETURNING VALUE(rv_json) TYPE string.
    "! Column metadata from a structure (used for BAPI/FM results)
    CLASS-METHODS cols_from_struct
      IMPORTING io_struct      TYPE REF TO cl_abap_structdescr
      RETURNING VALUE(rt_cols) TYPE zif_mcp_types=>tt_col.
ENDCLASS.

CLASS zcl_mcp_envelope IMPLEMENTATION.

  METHOD error.
    DATA lt_pairs TYPE string_table.
    APPEND zcl_mcp_json=>pair( iv_key = `status` iv_raw = zcl_mcp_json=>str( `ERROR` ) ) TO lt_pairs.
    IF iv_action IS NOT INITIAL.
      APPEND zcl_mcp_json=>pair( iv_key = `action` iv_raw = zcl_mcp_json=>str( iv_action ) ) TO lt_pairs.
    ENDIF.
    APPEND zcl_mcp_json=>pair( iv_key = `message` iv_raw = zcl_mcp_json=>str( iv_message ) ) TO lt_pairs.
    rv_json = zcl_mcp_json=>object( lt_pairs ).
  ENDMETHOD.

  METHOD columns.
    DATA lt_items TYPE string_table.
    LOOP AT it_cols INTO DATA(ls_col).
      APPEND zcl_mcp_json=>object( VALUE #(
        ( zcl_mcp_json=>pair( iv_key = `name`  iv_raw = zcl_mcp_json=>str( ls_col-name ) ) )
        ( zcl_mcp_json=>pair( iv_key = `label` iv_raw = zcl_mcp_json=>str( ls_col-label ) ) )
        ( zcl_mcp_json=>pair( iv_key = `type`  iv_raw = zcl_mcp_json=>str( ls_col-datatype ) ) ) ) )
        TO lt_items.
    ENDLOOP.
    rv_json = zcl_mcp_json=>array( lt_items ).
  ENDMETHOD.

  METHOD rows.
    DATA lt_rows  TYPE string_table.
    DATA lt_cells TYPE string_table.
    FIELD-SYMBOLS <ls_row> TYPE any.
    FIELD-SYMBOLS <lv_val> TYPE any.

    LOOP AT it_data ASSIGNING <ls_row>.
      IF iv_max > 0 AND lines( lt_rows ) >= iv_max.
        EXIT.
      ENDIF.
      CLEAR lt_cells.
      LOOP AT it_cols INTO DATA(ls_col).
        ASSIGN COMPONENT ls_col-comp OF STRUCTURE <ls_row> TO <lv_val>.
        IF sy-subrc = 0.
          APPEND cell( iv_value = <lv_val> is_col = ls_col ) TO lt_cells.
        ELSE.
          APPEND `null` TO lt_cells.
        ENDIF.
      ENDLOOP.
      APPEND zcl_mcp_json=>array( lt_cells ) TO lt_rows.
    ENDLOOP.
    rv_json = zcl_mcp_json=>array( lt_rows ).
  ENDMETHOD.

  METHOD cell.
    DATA lv_text TYPE string.
    DATA lv_out  TYPE c LENGTH 255.

    CASE is_col-inttype.
      WHEN 'I' OR 'b' OR 's' OR '8' OR 'P' OR 'F' OR 'a' OR 'e'.
        rv_json = |{ iv_value }|.
        CONDENSE rv_json NO-GAPS.

      WHEN 'D'.
        lv_text = iv_value.
        IF lv_text IS INITIAL OR lv_text = '00000000'.
          rv_json = `""`.
        ELSE.
          rv_json = zcl_mcp_json=>str( |{ lv_text(4) }-{ lv_text+4(2) }-{ lv_text+6(2) }| ).
        ENDIF.

      WHEN 'T'.
        lv_text = iv_value.
        rv_json = zcl_mcp_json=>str( |{ lv_text(2) }:{ lv_text+2(2) }:{ lv_text+4(2) }| ).

      WHEN 'X' OR 'y'.
        lv_text = iv_value.                         " hex representation
        rv_json = zcl_mcp_json=>str( lv_text ).

      WHEN OTHERS.
        lv_text = iv_value.
        IF is_col-convexit IS NOT INITIAL.
          DATA(lv_fm) = |CONVERSION_EXIT_{ is_col-convexit }_OUTPUT|.
          TRY.
              CALL FUNCTION lv_fm
                EXPORTING  input  = iv_value
                IMPORTING  output = lv_out
                EXCEPTIONS OTHERS = 1.
              IF sy-subrc = 0.
                lv_text = lv_out.
              ENDIF.
            CATCH cx_sy_dyn_call_error.
              " keep internal value
          ENDTRY.
        ENDIF.
        rv_json = zcl_mcp_json=>str( lv_text ).
    ENDCASE.
  ENDMETHOD.

  METHOD cols_from_struct.
    LOOP AT io_struct->components INTO DATA(ls_comp).
      DATA(lo_type) = io_struct->get_component_type( ls_comp-name ).
      IF lo_type->kind <> cl_abap_typedescr=>kind_elem.
        CONTINUE.                                   " nested structures/tables are skipped
      ENDIF.
      DATA(ls_col) = VALUE zif_mcp_types=>ty_col( comp     = ls_comp-name
                                                  name     = ls_comp-name
                                                  label    = ls_comp-name
                                                  inttype  = lo_type->type_kind
                                                  datatype = lo_type->type_kind ).
      DATA(lo_elem) = CAST cl_abap_elemdescr( lo_type ).
      IF lo_elem->is_ddic_type( ) = abap_true.
        DATA(ls_dfies) = lo_elem->get_ddic_field( ).
        ls_col-label    = COND string( WHEN ls_dfies-scrtext_m IS NOT INITIAL THEN ls_dfies-scrtext_m
                                       ELSE ls_dfies-fieldtext ).
        ls_col-convexit = ls_dfies-convexit.
        ls_col-datatype = ls_dfies-datatype.
      ENDIF.
      APPEND ls_col TO rt_cols.
    ENDLOOP.
  ENDMETHOD.

ENDCLASS.
