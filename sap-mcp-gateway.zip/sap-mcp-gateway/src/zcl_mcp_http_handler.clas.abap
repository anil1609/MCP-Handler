"! SICF handler for /sap/zmcp/gateway
"!   POST /list | /describe | /query | /call   (JSON body)
"!   GET  /health
"! Business errors return HTTP 200 with "status":"ERROR" so the LLM can read and retry.
CLASS zcl_mcp_http_handler DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_http_extension.
ENDCLASS.

CLASS zcl_mcp_http_handler IMPLEMENTATION.

  METHOD if_http_extension~handle_request.
    DATA lv_status TYPE i VALUE 200.
    DATA lv_json   TYPE string.

    DATA(lv_method) = to_upper( server->request->get_header_field( '~request_method' ) ).
    DATA(lv_path)   = to_lower( server->request->get_header_field( '~path_info' ) ).
    DATA(lv_body)   = server->request->get_cdata( ).
    DATA(lo_gw)     = NEW zcl_mcp_gateway( ).

    IF lv_method = `GET` AND lv_path = `/health`.
      lv_json = `{"status":"OK"}`.
    ELSEIF lv_method <> `POST`.
      lv_status = 405.
      lv_json = zcl_mcp_envelope=>error( `Use POST with a JSON body.` ).
    ELSE.
      CASE lv_path.
        WHEN `/list`.
          lv_json = lo_gw->list_objects( lv_body ).
        WHEN `/describe`.
          lv_json = lo_gw->describe_object( lv_body ).
        WHEN `/query`.
          lv_json = lo_gw->query_data( lv_body ).
        WHEN `/call`.
          lv_json = lo_gw->call_function( lv_body ).
        WHEN OTHERS.
          lv_status = 404.
          lv_json = zcl_mcp_envelope=>error( |Unknown path '{ lv_path }'. Use /list, /describe, /query or /call.| ).
      ENDCASE.
    ENDIF.

    server->response->set_status( code = lv_status reason = COND #( WHEN lv_status = 200 THEN `OK` ELSE `Error` ) ).
    server->response->set_content_type( 'application/json; charset=utf-8' ).
    server->response->set_cdata( lv_json ).
  ENDMETHOD.

ENDCLASS.
