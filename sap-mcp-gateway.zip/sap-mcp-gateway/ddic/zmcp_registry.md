# Table ZMCP_REGISTRY

Transparent table, delivery class C, client-dependent, display/maintenance allowed (SM30).

| Field | Key | Data type | Length | Description |
|---|---|---|---|---|
| MANDT | X | CLNT | 3 | Client |
| OBJ_NAME | X | CHAR | 40 | Table / CDS entity / BAPI / FM / OData object name, or domain name for DOMAIN rows (uppercase) |
| OBJ_TYPE | | CHAR | 10 | TABLE, CDS, ODATA, BAPI, FM, DOMAIN |
| DOMAIN | | CHAR | 20 | Business domain, e.g. PROCUREMENT |
| DESCRIPTION | | CHAR | 255 | LLM-facing: when to use this object. DOMAIN rows: domain rules |
| ACTIVE | | CHAR | 1 | 'X' = reachable |
| MAX_ROWS | | INT4 | 10 | Row cap for this object (0 = default 100, hard cap 1000) |
| MANDATORY_FILTERS | | CHAR | 255 | Comma list of fields that must be filtered, e.g. `LIFNR` |
| HIDDEN_FIELDS | | CHAR | 255 | Comma list of fields never exposed |
| RETURN_TABLES | | CHAR | 255 | BAPI/FM: comma list of output parameters to return (blank = all) |
| RELATIONS | | CHAR | 255 | Optional join overrides: `TARGET:FIELD=FIELD,FIELD=FIELD;TARGET2:...` |
| SERVICE_REF | | CHAR | 255 | ODATA only, see below |

Only OBJ_NAME, OBJ_TYPE, DESCRIPTION and ACTIVE are required (plus SERVICE_REF for ODATA).
Fields, keys, labels, conversion exits, relations and CDS associations are read at runtime.

## OBJ_TYPE behaviour

| Type | Read via | Authorization | Joins | Notes |
|---|---|---|---|---|
| TABLE | dynamic Open SQL | S_TABU_DIS/S_TABU_NAM + org-level rows (EKORG/WERKS/BUKRS) | yes | ECC and S/4 |
| CDS | dynamic Open SQL on the entity | the entity's DCL | yes, plus association paths in fields | Use released VDM views (I_*, A_*); no CDS parameters |
| ODATA | V4 local client proxy or V2 loopback HTTP | the service's own checks + DCL | no (chain queries) | for services with logic beyond their CDS view |
| BAPI / FM | dynamic CALL FUNCTION + ROLLBACK WORK | the function's own checks | n/a | read-only functions only |

## SERVICE_REF format (ODATA)

- V4 (S/4): `V4;<repository>;<service id>;<version>;<entity set>;<row type>`
  - repository: `SRVD` for RAP service definitions, `DEFAULT` for SEGW services
  - entity set: internal (uppercase) name
  - row type: DDIC type of one row, normally the CDS entity behind the entity set
  - example: `V4;SRVD;API_PURCHASEORDER_2;0001;PURCHASEORDER;<CDS entity behind the set>`
- V2: `V2;<SM59 destination>;<service root path>;<entity set>`
  - destination: type H to the same system, logon as current user (SSO/logon ticket), no technical user
  - entity set: exact external name (case-sensitive)
  - example: `V2;ZMCP_LOOPBACK;/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV;A_PurchaseOrder`

Prefer CDS over ODATA when the service is a plain projection of a CDS view: same data, faster, simpler.

## Seed entries, ECC (tables)

| OBJ_NAME | OBJ_TYPE | DOMAIN | DESCRIPTION | ACTIVE | MAX_ROWS | MANDATORY_FILTERS | RETURN_TABLES |
|---|---|---|---|---|---|---|---|
| EKKO | TABLE | PROCUREMENT | PO headers: supplier (LIFNR), PO date (BEDAT), purch. org, PO type | X | 200 | LIFNR | |
| EKPO | TABLE | PROCUREMENT | PO items: material, quantity, plant, net price, deletion flag (LOEKZ) | X | 500 | EBELN | |
| EKET | TABLE | PROCUREMENT | PO schedule lines: delivery date (EINDT), scheduled and received qty | X | 500 | EBELN | |
| EKBE | TABLE | PROCUREMENT | PO history: goods receipts and invoices per item | X | 500 | EBELN | |
| LFA1 | TABLE | MASTERDATA | Supplier name, city, country | X | 100 | | |
| MAKT | TABLE | MASTERDATA | Material descriptions (language added automatically in joins) | X | 100 | MATNR | |
| BAPI_PO_GETDETAIL1 | BAPI | PROCUREMENT | Full detail of one PO incl. items and schedules | X | | | POHEADER,POITEM,POSCHEDULE |
| PROCUREMENT | DOMAIN | | Exclude deleted items (EKPO-LOEKZ <> blank). GR/IR history is in EKBE (VGABE 1 = GR, 2 = invoice). | X | | | |

Derived relations (no RELATIONS entry needed): EKKO->EKPO (EBELN), EKPO->EKET (EBELN, EBELP),
EKPO->EKBE (EBELN, EBELP), EKKO->LFA1 (LIFNR), EKPO->MAKT (MATNR + logon language).

## Seed entries, S/4 (CDS and OData)

Check the exact released view and service names on your release first.

| OBJ_NAME | OBJ_TYPE | DOMAIN | DESCRIPTION | ACTIVE | MAX_ROWS | MANDATORY_FILTERS | SERVICE_REF |
|---|---|---|---|---|---|---|---|
| I_PURCHASEORDERAPI01 | CDS | PROCUREMENT | PO headers (preferred). Items via _PurchaseOrderItem | X | 200 | SUPPLIER | |
| I_PURCHASEORDERITEMAPI01 | CDS | PROCUREMENT | PO items: material, quantity, plant, net amount | X | 500 | PURCHASEORDER | |
| I_PURORDSCHEDULELINEAPI01 | CDS | PROCUREMENT | Delivery dates and open quantities per item | X | 500 | PURCHASEORDER | |
| PO_V2_API | ODATA | PROCUREMENT | Standard PO API (V2) - use only if the CDS views are not enough | X | 200 | Supplier | V2;ZMCP_LOOPBACK;/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV;A_PurchaseOrder |
