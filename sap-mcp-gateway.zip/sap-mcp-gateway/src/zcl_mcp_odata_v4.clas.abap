"! OData V4 via the local client proxy: the service runs inside the same ABAP session,
"! so there is no HTTP hop and the caller's authorizations apply (incl. the service's own
"! logic and the DCL of the CDS entities behind it).
"! S/4HANA only. Do NOT create this class on ECC; ZCL_MCP_ODATA_HANDLER instantiates it
"! dynamically and reports "not installed" if it is missing.
"! Property names are the internal (uppercase) ABAP names = fields of the row type.
CLASS zcl_mcp_odata_v4 DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES zif_mcp_source_handler.
  PRIVATE SECTION.
    METHODS get_field
      IMPORTING it_fields       TYPE zif_mcp_types=>tt_dfies
                it_hidden       TYPE string_table
                iv_name         TYPE string
      RETURNING VALUE(rs_field) TYPE dfies
      RAISING   zcx_mcp_error.
    METHODS build_range
      IMPORTING is_srv          TYPE zcl_mcp_odata_handler=>ty_service
                is_field        TYPE dfies
                is_filter       TYPE zif_mcp_types=>ty_filter
      RETURNING VALUE(rr_range) TYPE REF TO data
      RAISING   zcx_mcp_error.
    METHODS add_range_row
      IMPORTING ir_range    TYPE REF TO data
                iv_option   TYPE string
                iv_low      TYPE string
                iv_high     TYPE string OPTIONAL
                is_field    TYPE dfies
                iv_typename TYPE string
                iv_convert  TYPE abap_bool DEFAULT abap_true
      RAISING   zcx_mcp_error.
ENDCLASS.

CLASS zcl_mcp_odata_v4 IMPLEMENTATION.

  METHOD zif_mcp_source_handler~describe.
    DATA lt_items TYPE string_table.
    DATA lt_pairs TYPE string_table.

    DATA(ls_srv)    = zcl_mcp_odata_handler=>parse_service( is_reg ).
    DATA(lt_fields) = zcl_mcp_metadata=>get_fields( ls_srv-row_type ).
    DATA(lt_hidden) = zcl_mcp_registry=>split_list( is_reg-hidden_fields ).

    LOOP AT lt_fields INTO DATA(ls_f).
      IF line_exists( lt_hidden[ table_line = CONV string( ls_f-fieldname ) ] ).
        CONTINUE.
      ENDIF.
      CLEAR lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `name`  iv_raw = zcl_mcp_json=>str( ls_f-fieldname ) ) TO lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `label` iv_raw = zcl_mcp_json=>str(
        COND string( WHEN ls_f-scrtext_m IS NOT INITIAL THEN ls_f-scrtext_m ELSE ls_f-fieldtext ) ) ) TO lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `type`  iv_raw = zcl_mcp_json=>str( ls_f-datatype ) ) TO lt_pairs.
      IF ls_f-keyflag = abap_true.
        APPEND zcl_mcp_json=>pair( iv_key = `key` iv_raw = `true` ) TO lt_pairs.
      ENDIF.
      IF ls_f-convexit IS NOT INITIAL.
        APPEND zcl_mcp_json=>pair( iv_key = `conversion` iv_raw = zcl_mcp_json=>str( ls_f-convexit ) ) TO lt_pairs.
      ENDIF.
      APPEND zcl_mcp_json=>object( lt_pairs ) TO lt_items.
    ENDLOOP.

    rv_json = zcl_mcp_odata_handler=>describe_json( is_reg = is_reg is_srv = ls_srv
                                                    iv_fields_json = zcl_mcp_json=>array( lt_items ) ).
  ENDMETHOD.

  METHOD zif_mcp_source_handler~query.
    DATA lt_select  TYPE /iwbep/if_cp_runtime_types=>ty_t_property_path.
    DATA lt_order   TYPE /iwbep/if_cp_runtime_types=>ty_t_sort_order.
    DATA lo_filter  TYPE REF TO /iwbep/if_cp_filter_node.
    DATA lt_cols    TYPE zif_mcp_types=>tt_col.
    DATA lt_refs    TYPE string_table.
    DATA lt_items   TYPE string_table.
    DATA lr_data    TYPE REF TO data.
    DATA lv_ref     TYPE string.
    DATA lv_dir     TYPE string.
    DATA lv_message TYPE string.
    FIELD-SYMBOLS <lt_data>  TYPE STANDARD TABLE.
    FIELD-SYMBOLS <lt_range> TYPE ANY TABLE.

    DATA(ls_srv)    = zcl_mcp_odata_handler=>parse_service( is_reg ).
    DATA(lt_fields) = zcl_mcp_metadata=>get_fields( ls_srv-row_type ).
    DATA(lt_hidden) = zcl_mcp_registry=>split_list( is_reg-hidden_fields ).

    " select list
    lt_refs = is_args-fields.
    IF lt_refs IS INITIAL.
      LOOP AT lt_fields INTO DATA(ls_def).
        IF NOT line_exists( lt_hidden[ table_line = CONV string( ls_def-fieldname ) ] ).
          APPEND CONV string( ls_def-fieldname ) TO lt_refs.
        ENDIF.
        IF lines( lt_refs ) >= zif_mcp_types=>c_default_fields.
          EXIT.
        ENDIF.
      ENDLOOP.
      lv_message = |No fields requested; returned the first { lines( lt_refs ) } properties. | &&
                   |Request specific fields for better results.|.
    ENDIF.
    LOOP AT lt_refs INTO lv_ref.
      DATA(ls_f) = get_field( it_fields = lt_fields it_hidden = lt_hidden iv_name = lv_ref ).
      APPEND CONV #( ls_f-fieldname ) TO lt_select.
      APPEND VALUE #( comp     = ls_f-fieldname
                      name     = ls_f-fieldname
                      label    = COND string( WHEN ls_f-scrtext_m IS NOT INITIAL THEN ls_f-scrtext_m ELSE ls_f-fieldtext )
                      inttype  = ls_f-inttype
                      datatype = ls_f-datatype
                      convexit = ls_f-convexit
                      typename = |{ ls_srv-row_type }-{ ls_f-fieldname }| ) TO lt_cols.
    ENDLOOP.

    DATA(lv_limit)  = zcl_mcp_odata_handler=>effective_limit( is_reg = is_reg iv_requested = is_args-max_rows ).
    DATA(lv_offset) = nmax( val1 = 0 val2 = nmin( val1 = is_args-offset val2 = zif_mcp_types=>c_max_offset ) ).

    TRY.
        DATA(lo_proxy) = /iwbep/cl_cp_client_proxy_factory=>create_v4_local_proxy(
                           VALUE #( repository_id   = ls_srv-repository
                                    service_id      = ls_srv-service_id
                                    service_version = ls_srv-service_ver ) ).
        DATA(lo_request) = lo_proxy->create_resource_for_entity_set( CONV #( ls_srv-entity_set )
                                   )->create_request_for_read( ).
        lo_request->set_select_properties( lt_select ).

        " filters: one range per filter, AND-combined
        DATA(lo_ff) = lo_request->create_filter_factory( ).
        LOOP AT is_args-filters INTO DATA(ls_filter).
          DATA(ls_ff) = get_field( it_fields = lt_fields it_hidden = lt_hidden iv_name = ls_filter-field ).
          DATA(lr_range) = build_range( is_srv = ls_srv is_field = ls_ff is_filter = ls_filter ).
          ASSIGN lr_range->* TO <lt_range>.
          DATA(lo_node) = lo_ff->create_by_range( iv_property_path = CONV #( ls_ff-fieldname )
                                                  it_range         = <lt_range> ).
          lo_filter = COND #( WHEN lo_filter IS BOUND THEN lo_filter->and( lo_node ) ELSE lo_node ).
        ENDLOOP.
        IF lo_filter IS BOUND.
          lo_request->set_filter( lo_filter ).
        ENDIF.

        " order by
        IF is_args-order_by IS NOT INITIAL.
          SPLIT is_args-order_by AT ',' INTO TABLE lt_items.
          LOOP AT lt_items INTO DATA(lv_item).
            CLEAR: lv_ref, lv_dir.
            lv_item = condense( lv_item ).
            SPLIT lv_item AT space INTO lv_ref lv_dir.
            DATA(ls_of) = get_field( it_fields = lt_fields it_hidden = lt_hidden iv_name = lv_ref ).
            APPEND VALUE #( property_path = CONV #( ls_of-fieldname )
                            descending    = xsdbool( to_upper( lv_dir ) CP 'DESC*' ) ) TO lt_order.
          ENDLOOP.
          lo_request->set_orderby( lt_order ).
        ENDIF.

        lo_request->set_top( lv_limit + 1 ).
        IF lv_offset > 0.
          lo_request->set_skip( lv_offset ).
        ENDIF.

        CREATE DATA lr_data TYPE STANDARD TABLE OF (ls_srv-row_type).
        ASSIGN lr_data->* TO <lt_data>.
        DATA(lo_response) = lo_request->execute( ).
        lo_response->get_business_data( IMPORTING et_business_data = <lt_data> ).

      CATCH /iwbep/cx_gateway INTO DATA(lx_gw).
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text  = |OData V4 request failed: { lx_gw->get_text( ) }|
                    previous = lx_gw.
    ENDTRY.

    DATA(lv_truncated) = xsdbool( lines( <lt_data> ) > lv_limit ).
    IF lv_truncated = abap_true.
      DATA(lv_cut_from) = lv_limit + 1.
      DELETE <lt_data> FROM lv_cut_from.
    ENDIF.

    rv_json = zcl_mcp_odata_handler=>query_json(
                is_reg          = is_reg
                iv_columns_json = zcl_mcp_envelope=>columns( lt_cols )
                iv_rows_json    = zcl_mcp_envelope=>rows( it_data = <lt_data> it_cols = lt_cols )
                iv_count        = lines( <lt_data> )
                iv_truncated    = lv_truncated
                iv_next_offset  = lv_offset + lv_limit
                iv_message      = lv_message ).
  ENDMETHOD.

  METHOD zif_mcp_source_handler~execute.
    RAISE EXCEPTION TYPE zcx_mcp_error
      EXPORTING iv_text = |{ is_reg-obj_name } is an OData entity set. Use queryData instead of callFunction.|.
  ENDMETHOD.

  METHOD get_field.
    DATA(lv_name) = to_upper( condense( iv_name ) ).
    READ TABLE it_fields INTO rs_field WITH KEY fieldname = lv_name.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Property '{ iv_name }' does not exist. Call describeObject to see valid fields.|.
    ENDIF.
    IF line_exists( it_hidden[ table_line = lv_name ] ).
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Property '{ iv_name }' is not exposed.|.
    ENDIF.
  ENDMETHOD.

  METHOD build_range.
    DATA lt_comp TYPE cl_abap_structdescr=>component_table.
    DATA lo_type TYPE REF TO cl_abap_typedescr.

    DATA(lv_typename) = |{ is_srv-row_type }-{ is_field-fieldname }|.
    cl_abap_typedescr=>describe_by_name(
      EXPORTING  p_name         = lv_typename
      RECEIVING  p_descr_ref    = lo_type
      EXCEPTIONS type_not_found = 1
                 OTHERS         = 2 ).
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Cannot resolve type { lv_typename }.|.
    ENDIF.

    lt_comp = VALUE #( ( name = 'SIGN'   type = cl_abap_elemdescr=>get_c( 1 ) )
                       ( name = 'OPTION' type = cl_abap_elemdescr=>get_c( 2 ) )
                       ( name = 'LOW'    type = CAST #( lo_type ) )
                       ( name = 'HIGH'   type = CAST #( lo_type ) ) ).
    DATA(lo_line)  = cl_abap_structdescr=>create( lt_comp ).
    DATA(lo_table) = cl_abap_tabledescr=>create( p_line_type = lo_line ).
    CREATE DATA rr_range TYPE HANDLE lo_table.

    DATA(lv_op) = to_upper( condense( is_filter-op ) ).
    IF lv_op IS INITIAL.
      lv_op = `EQ`.
    ENDIF.

    CASE lv_op.
      WHEN `EQ` OR `NE` OR `GT` OR `GE` OR `LT` OR `LE`.
        add_range_row( ir_range = rr_range iv_option = lv_op iv_low = is_filter-value
                       is_field = is_field iv_typename = lv_typename ).
      WHEN `BT`.
        add_range_row( ir_range = rr_range iv_option = `BT` iv_low = is_filter-low iv_high = is_filter-high
                       is_field = is_field iv_typename = lv_typename ).
      WHEN `IN`.
        IF is_filter-values IS INITIAL.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Operator IN needs a non-empty 'values' array (field { is_filter-field }).|.
        ENDIF.
        LOOP AT is_filter-values INTO DATA(lv_val).
          add_range_row( ir_range = rr_range iv_option = `EQ` iv_low = lv_val
                         is_field = is_field iv_typename = lv_typename ).
        ENDLOOP.
      WHEN `CP`.
        add_range_row( ir_range = rr_range iv_option = `CP`
                       iv_low = COND #( WHEN is_field-lowercase IS INITIAL THEN to_upper( is_filter-value )
                                        ELSE is_filter-value )
                       is_field = is_field iv_typename = lv_typename iv_convert = abap_false ).
      WHEN OTHERS.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |Unsupported operator '{ lv_op }'. Use EQ, NE, GT, GE, LT, LE, BT, IN or CP.|.
    ENDCASE.
  ENDMETHOD.

  METHOD add_range_row.
    FIELD-SYMBOLS <lt_range> TYPE STANDARD TABLE.
    FIELD-SYMBOLS <ls_line>  TYPE any.
    FIELD-SYMBOLS <lv_comp>  TYPE any.

    ASSIGN ir_range->* TO <lt_range>.
    APPEND INITIAL LINE TO <lt_range> ASSIGNING <ls_line>.

    ASSIGN COMPONENT 'SIGN' OF STRUCTURE <ls_line> TO <lv_comp>.
    <lv_comp> = 'I'.
    ASSIGN COMPONENT 'OPTION' OF STRUCTURE <ls_line> TO <lv_comp>.
    <lv_comp> = iv_option.
    ASSIGN COMPONENT 'LOW' OF STRUCTURE <ls_line> TO <lv_comp>.
    <lv_comp> = COND string( WHEN iv_convert = abap_true
                             THEN zcl_mcp_value=>to_internal( is_field = is_field iv_typename = iv_typename iv_value = iv_low )
                             ELSE iv_low ).
    IF iv_option = `BT`.
      ASSIGN COMPONENT 'HIGH' OF STRUCTURE <ls_line> TO <lv_comp>.
      <lv_comp> = zcl_mcp_value=>to_internal( is_field = is_field iv_typename = iv_typename iv_value = iv_high ).
    ENDIF.
  ENDMETHOD.

ENDCLASS.
