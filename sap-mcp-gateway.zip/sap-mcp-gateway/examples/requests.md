# End-to-end example

User question: "Which open PO items for supplier 100045 in plant 1000 did we order this month, with material text?"

All calls: `POST https://<host>/sap/zmcp/gateway/<path>`, `Content-Type: application/json`.
Response values below are illustrative.

## 1. listObjects  (`/list`)

```json
{"domain":"PROCUREMENT","search":"purchase order"}
```
```json
{"status":"OK","action":"LIST",
 "objects":[
   {"name":"EKKO","type":"TABLE","domain":"PROCUREMENT","description":"PO headers: supplier (LIFNR), PO date (BEDAT), purch. org, PO type"},
   {"name":"EKPO","type":"TABLE","domain":"PROCUREMENT","description":"PO items: material, quantity, plant, net price, deletion flag (LOEKZ)"},
   {"name":"BAPI_PO_GETDETAIL1","type":"BAPI","domain":"PROCUREMENT","description":"Full detail of one PO incl. items and schedules"}],
 "domains":[{"name":"PROCUREMENT","rules":"Exclude deleted items (EKPO-LOEKZ <> blank). GR/IR history is in EKBE (VGABE 1 = GR, 2 = invoice)."}],
 "message":"Next: call describeObject with objName before querying."}
```

## 2. describeObject  (`/describe`)

```json
{"objName":"EKKO"}
```
```json
{"status":"OK","action":"DESCRIBE","object":"EKKO","type":"TABLE","domain":"PROCUREMENT",
 "maxRows":200,"mandatoryFilters":["LIFNR"],
 "fields":[
   {"name":"EBELN","label":"Purchasing Doc.","type":"CHAR","length":10,"key":true,"conversion":"ALPHA"},
   {"name":"LIFNR","label":"Vendor","type":"CHAR","length":10,"conversion":"ALPHA"},
   {"name":"BEDAT","label":"Doc. Date","type":"DATS","length":8},
   {"name":"EKORG","label":"Purch. Org.","type":"CHAR","length":4}],
 "relations":[
   {"objName":"EKPO","keys":[{"left":"EKKO.EBELN","right":"EBELN"}],"origin":"derived"},
   {"objName":"LFA1","keys":[{"left":"EKKO.LIFNR","right":"LIFNR"}],"origin":"derived"}],
 "hint":"Use queryData. When joining, qualify fields as OBJECT.FIELD ..."}
```

(The agent may also describe EKPO to see `MATNR`, `WERKS`, `LOEKZ` and its relation to MAKT.)

## 3. queryData with joins  (`/query`)

```json
{"objName":"EKKO",
 "joins":[
   {"objName":"EKPO","keys":[{"left":"EKKO.EBELN","right":"EBELN"}]},
   {"objName":"MAKT","type":"LEFT","keys":[{"left":"EKPO.MATNR","right":"MATNR"}]}],
 "fields":["EKKO.EBELN","EKKO.BEDAT","EKPO.EBELP","EKPO.MATNR","MAKT.MAKTX","EKPO.MENGE","EKPO.MEINS"],
 "filters":[
   {"field":"EKKO.LIFNR","op":"EQ","value":"100045"},
   {"field":"EKKO.BEDAT","op":"BT","low":"2026-10-01","high":"2026-10-31"},
   {"field":"EKPO.WERKS","op":"EQ","value":"1000"},
   {"field":"EKPO.LOEKZ","op":"EQ","value":""}],
 "orderBy":"EKKO.BEDAT DESC",
 "maxRows":50}
```

What the backend builds (user authorized for some purchasing orgs only):

```sql
SELECT t0~EBELN AS C001, t0~BEDAT AS C002, t1~EBELP AS C003, t1~MATNR AS C004,
       t2~MAKTX AS C005, t1~MENGE AS C006, t1~MEINS AS C007
  FROM EKKO AS t0
  INNER JOIN EKPO AS t1 ON t1~EBELN = t0~EBELN
  LEFT OUTER JOIN MAKT AS t2 ON t2~MATNR = t1~MATNR AND t2~SPRAS = 'E'
  WHERE ( t0~LIFNR = '0000100045' AND t0~BEDAT BETWEEN '20261001' AND '20261031'
          AND t1~WERKS = '1000' AND t1~LOEKZ = '' )
    AND t0~EKORG IN ( '1000', '2000' )
  ORDER BY t0~BEDAT DESCENDING, t0~EBELN ASCENDING
  UP TO 51 ROWS
```

```json
{"status":"OK","action":"QUERY","source":"EKKO",
 "columns":[
   {"name":"EKKO.EBELN","label":"Purchasing Doc.","type":"CHAR"},
   {"name":"EKKO.BEDAT","label":"Doc. Date","type":"DATS"},
   {"name":"EKPO.EBELP","label":"Item","type":"NUMC"},
   {"name":"EKPO.MATNR","label":"Material","type":"CHAR"},
   {"name":"MAKT.MAKTX","label":"Material Description","type":"CHAR"},
   {"name":"EKPO.MENGE","label":"PO Quantity","type":"QUAN"},
   {"name":"EKPO.MEINS","label":"Order Unit","type":"UNIT"}],
 "rows":[
   ["4500001301","2026-10-05","00010","BRG-6204","Ball bearing 6204",120.000,"EA"],
   ["4500001234","2026-10-02","00010","BRG-6205","Ball bearing 6205",50.000,"EA"]],
 "rowCount":2,"truncated":false,"nextOffset":null,"message":""}
```

## 4. callFunction  (`/call`)

```json
{"objName":"BAPI_PO_GETDETAIL1",
 "params":{"PURCHASEORDER":"4500001234","ITEMS":"X","SCHEDULES":"X"}}
```
```json
{"status":"OK","action":"CALL","object":"BAPI_PO_GETDETAIL1","message":"",
 "values":{},
 "resultSets":[
   {"name":"POHEADER","columns":[...],"rows":[[...]],"rowCount":1,"truncated":false},
   {"name":"POITEM","columns":[...],"rows":[[...]],"rowCount":1,"truncated":false},
   {"name":"POSCHEDULE","columns":[...],"rows":[[...]],"rowCount":1,"truncated":false}]}
```

## Typical error responses (the LLM corrects itself)

```json
{"status":"ERROR","action":"QUERY","message":"Mandatory filter(s) missing for EKKO: LIFNR."}
{"status":"ERROR","action":"QUERY","message":"Field 'VENDOR' does not exist in EKKO. Call describeObject for EKKO to see valid fields."}
{"status":"ERROR","action":"QUERY","message":"Join EKKO.ERNAM = LFA1.LIFNR is not an allowed relation. Use the relations listed by describeObject."}
{"status":"ERROR","action":"DESCRIBE","message":"Object MSEG is not registered or not active. Call listObjects to see available objects."}
```

## 5. CDS entity with an association path (S/4)

```json
{"objName":"I_PURCHASEORDERAPI01",
 "fields":["PURCHASEORDER","CREATIONDATE","_SUPPLIER.SUPPLIERNAME"],
 "filters":[
   {"field":"SUPPLIER","op":"EQ","value":"100045"},
   {"field":"CREATIONDATE","op":"BT","low":"2026-10-01","high":"2026-10-31"}],
 "orderBy":"CREATIONDATE DESC"}
```

Backend (DCL applied automatically; `_SUPPLIER` target must be registered):

```sql
SELECT t0~PURCHASEORDER AS C001, t0~CREATIONDATE AS C002, t0~\_SUPPLIER-SUPPLIERNAME AS C003
  FROM I_PURCHASEORDERAPI01 AS t0
  WHERE t0~SUPPLIER = '0000100045' AND t0~CREATIONDATE BETWEEN '20261001' AND '20261031'
  ORDER BY t0~CREATIONDATE DESCENDING, t0~PURCHASEORDER ASCENDING
```

## 6. OData V2 entity set

Registry: `PO_V2_API`, SERVICE_REF `V2;ZMCP_LOOPBACK;/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV;A_PurchaseOrder`

```json
{"objName":"PO_V2_API",
 "fields":["PurchaseOrder","Supplier","PurchaseOrderDate"],
 "filters":[{"field":"Supplier","op":"EQ","value":"100045"},
            {"field":"PurchaseOrderDate","op":"GE","value":"2026-10-01"}],
 "orderBy":"PurchaseOrderDate desc","maxRows":20}
```

Backend request through the loopback destination (URL-encoded in reality):

```
GET /sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV/A_PurchaseOrder?$format=json&$top=21&$skip=0
    &$select=PurchaseOrder,Supplier,PurchaseOrderDate
    &$filter=Supplier eq '100045' and PurchaseOrderDate ge datetime'2026-10-01T00:00:00'
    &$orderby=PurchaseOrderDate desc
```

## 7. OData V4 entity set (local client proxy)

Registry: SERVICE_REF `V4;SRVD;<service id>;0001;<ENTITY SET>;<CDS entity behind the set>`

```json
{"objName":"PO_V4_API",
 "fields":["PURCHASEORDER","SUPPLIER"],
 "filters":[{"field":"SUPPLIER","op":"IN","values":["100045","100046"]}]}
```

Filters become ranges (`SUPPLIER: I EQ 0000100045, I EQ 0000100046`) passed to the proxy's filter factory;
the service runs in the same session with the caller's authorizations.
