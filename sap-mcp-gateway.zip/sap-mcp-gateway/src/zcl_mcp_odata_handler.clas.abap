"! Handler for ODATA objects. SERVICE_REF in ZMCP_REGISTRY decides the protocol:
"!   V4;<repository>;<service id>;<version>;<entity set>;<row DDIC type>
"!        -> local client proxy in the same session (ZCL_MCP_ODATA_V4, S/4 only, created dynamically)
"!   V2;<SM59 HTTP destination>;<service root path>;<entity set>
"!        -> HTTP call to the same system through a loopback destination with current-user logon
"! OData objects cannot be joined; the agent chains queries instead.
CLASS zcl_mcp_odata_handler DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES zif_mcp_source_handler.

    TYPES: BEGIN OF ty_service,
             version     TYPE string,   " V4 | V2
             repository  TYPE string,   " V4: SRVD (RAP) or DEFAULT (SEGW)
             service_id  TYPE string,   " V4
             service_ver TYPE string,   " V4
             destination TYPE string,   " V2: SM59 type H, loopback, current-user logon
             path        TYPE string,   " V2: e.g. /sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV
             entity_set  TYPE string,
             row_type    TYPE string,   " V4: DDIC type of one row (CDS entity behind the set)
           END OF ty_service.

    CLASS-METHODS parse_service
      IMPORTING is_reg        TYPE zmcp_registry
      RETURNING VALUE(rs_srv) TYPE ty_service
      RAISING   zcx_mcp_error.
    "! Mandatory filters (case-insensitive property names)
    CLASS-METHODS check_mandatory
      IMPORTING is_reg     TYPE zmcp_registry
                it_filters TYPE zif_mcp_types=>tt_filter
      RAISING   zcx_mcp_error.
    CLASS-METHODS effective_limit
      IMPORTING is_reg          TYPE zmcp_registry
                iv_requested    TYPE i
      RETURNING VALUE(rv_limit) TYPE i.
    CLASS-METHODS describe_json
      IMPORTING is_reg         TYPE zmcp_registry
                is_srv         TYPE ty_service
                iv_fields_json TYPE string
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS query_json
      IMPORTING is_reg          TYPE zmcp_registry
                iv_columns_json TYPE string
                iv_rows_json    TYPE string
                iv_count        TYPE i
                iv_truncated    TYPE abap_bool
                iv_next_offset  TYPE i
                iv_message      TYPE string
      RETURNING VALUE(rv_json)  TYPE string.

  PRIVATE SECTION.
    TYPES: BEGIN OF ty_prop,
             name     TYPE string,      " exact (case-sensitive) property name
             edm_type TYPE string,
             label    TYPE string,
             key      TYPE abap_bool,
           END OF ty_prop,
           tt_prop TYPE STANDARD TABLE OF ty_prop WITH EMPTY KEY.
    TYPES: BEGIN OF ty_nv,
             name    TYPE string,
             value   TYPE string,
             is_null TYPE abap_bool,
           END OF ty_nv,
           tt_nv     TYPE HASHED TABLE OF ty_nv WITH UNIQUE KEY name,
           tt_v2_row TYPE STANDARD TABLE OF tt_nv WITH EMPTY KEY.

    METHODS get_v4
      RETURNING VALUE(ro_v4) TYPE REF TO zif_mcp_source_handler
      RAISING   zcx_mcp_error.
    METHODS describe_v2
      IMPORTING is_reg         TYPE zmcp_registry
                is_srv         TYPE ty_service
      RETURNING VALUE(rv_json) TYPE string
      RAISING   zcx_mcp_error.
    METHODS query_v2
      IMPORTING is_reg         TYPE zmcp_registry
                is_srv         TYPE ty_service
                is_args        TYPE zif_mcp_types=>ty_query_args
      RETURNING VALUE(rv_json) TYPE string
      RAISING   zcx_mcp_error.
    METHODS v2_properties
      IMPORTING is_srv          TYPE ty_service
                is_reg          TYPE zmcp_registry
      RETURNING VALUE(rt_props) TYPE tt_prop
      RAISING   zcx_mcp_error.
    METHODS v2_find
      IMPORTING it_props       TYPE tt_prop
                iv_name        TYPE string
      RETURNING VALUE(rs_prop) TYPE ty_prop
      RAISING   zcx_mcp_error.
    METHODS v2_filter
      IMPORTING it_props         TYPE tt_prop
                it_filters       TYPE zif_mcp_types=>tt_filter
      RETURNING VALUE(rv_filter) TYPE string
      RAISING   zcx_mcp_error.
    METHODS v2_literal
      IMPORTING is_prop       TYPE ty_prop
                iv_value      TYPE string
      RETURNING VALUE(rv_lit) TYPE string
      RAISING   zcx_mcp_error.
    METHODS v2_cell
      IMPORTING is_prop        TYPE ty_prop
                is_nv          TYPE ty_nv
                iv_found       TYPE abap_bool
      RETURNING VALUE(rv_json) TYPE string.
    METHODS http_get
      IMPORTING is_srv         TYPE ty_service
                iv_relative    TYPE string
      RETURNING VALUE(rv_body) TYPE string
      RAISING   zcx_mcp_error.
    METHODS parse_v2_results
      IMPORTING iv_json        TYPE string
      RETURNING VALUE(rt_rows) TYPE tt_v2_row
      RAISING   zcx_mcp_error.
    CLASS-METHODS attr
      IMPORTING iv_tag          TYPE string
                iv_name         TYPE string
      RETURNING VALUE(rv_value) TYPE string.
ENDCLASS.

CLASS zcl_mcp_odata_handler IMPLEMENTATION.

  " ===================================================================== interface
  METHOD zif_mcp_source_handler~describe.
    DATA(ls_srv) = parse_service( is_reg ).
    IF ls_srv-version = `V4`.
      rv_json = get_v4( )->describe( is_reg ).
    ELSE.
      rv_json = describe_v2( is_reg = is_reg is_srv = ls_srv ).
    ENDIF.
  ENDMETHOD.

  METHOD zif_mcp_source_handler~query.
    IF is_args-joins IS NOT INITIAL.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |OData objects cannot be joined. Query { is_reg-obj_name } alone and chain queries.|.
    ENDIF.
    DATA(ls_srv) = parse_service( is_reg ).
    check_mandatory( is_reg = is_reg it_filters = is_args-filters ).
    IF ls_srv-version = `V4`.
      rv_json = get_v4( )->query( is_reg = is_reg is_args = is_args ).
    ELSE.
      rv_json = query_v2( is_reg = is_reg is_srv = ls_srv is_args = is_args ).
    ENDIF.
  ENDMETHOD.

  METHOD zif_mcp_source_handler~execute.
    RAISE EXCEPTION TYPE zcx_mcp_error
      EXPORTING iv_text = |{ is_reg-obj_name } is an OData entity set. Use queryData instead of callFunction.|.
  ENDMETHOD.

  METHOD get_v4.
    " created dynamically so this class also activates where the V4 client proxy is not available (ECC)
    TRY.
        CREATE OBJECT ro_v4 TYPE ('ZCL_MCP_ODATA_V4').
      CATCH cx_sy_create_object_error.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = `OData V4 support (class ZCL_MCP_ODATA_V4) is not installed on this system.`.
    ENDTRY.
  ENDMETHOD.

  " ===================================================================== shared helpers
  METHOD parse_service.
    DATA lt_parts TYPE string_table.

    SPLIT is_reg-service_ref AT ';' INTO TABLE lt_parts.
    LOOP AT lt_parts ASSIGNING FIELD-SYMBOL(<lv_part>).
      <lv_part> = condense( <lv_part> ).
    ENDLOOP.
    rs_srv-version = to_upper( VALUE string( lt_parts[ 1 ] OPTIONAL ) ).

    CASE rs_srv-version.
      WHEN `V4`.
        IF lines( lt_parts ) < 6.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |SERVICE_REF of { is_reg-obj_name } must be | &&
                                |V4;<repository>;<service id>;<version>;<entity set>;<row type>.|.
        ENDIF.
        rs_srv-repository  = to_upper( lt_parts[ 2 ] ).
        rs_srv-service_id  = to_upper( lt_parts[ 3 ] ).
        rs_srv-service_ver = lt_parts[ 4 ].
        rs_srv-entity_set  = to_upper( lt_parts[ 5 ] ).
        rs_srv-row_type    = to_upper( lt_parts[ 6 ] ).
      WHEN `V2`.
        IF lines( lt_parts ) < 4.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |SERVICE_REF of { is_reg-obj_name } must be | &&
                                |V2;<SM59 destination>;<service path>;<entity set>.|.
        ENDIF.
        rs_srv-destination = to_upper( lt_parts[ 2 ] ).
        rs_srv-path        = lt_parts[ 3 ].
        rs_srv-entity_set  = lt_parts[ 4 ].           " case-sensitive in V2
      WHEN OTHERS.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |SERVICE_REF of { is_reg-obj_name } must start with V4 or V2.|.
    ENDCASE.
  ENDMETHOD.

  METHOD check_mandatory.
    DATA lt_missing TYPE string_table.
    DATA(lt_required) = zcl_mcp_registry=>split_list( is_reg-mandatory_filters ).
    LOOP AT lt_required INTO DATA(lv_req).
      DATA(lv_found) = abap_false.
      LOOP AT it_filters INTO DATA(ls_filter).
        IF to_upper( condense( ls_filter-field ) ) = lv_req.
          lv_found = abap_true.
          EXIT.
        ENDIF.
      ENDLOOP.
      IF lv_found = abap_false.
        APPEND lv_req TO lt_missing.
      ENDIF.
    ENDLOOP.
    IF lt_missing IS NOT INITIAL.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Mandatory filter(s) missing for { is_reg-obj_name }: | &&
                            |{ concat_lines_of( table = lt_missing sep = `, ` ) }.|.
    ENDIF.
  ENDMETHOD.

  METHOD effective_limit.
    rv_limit = COND #( WHEN is_reg-max_rows > 0 THEN is_reg-max_rows ELSE zif_mcp_types=>c_default_max_rows ).
    rv_limit = nmin( val1 = rv_limit val2 = zif_mcp_types=>c_hard_max_rows ).
    IF iv_requested > 0.
      rv_limit = nmin( val1 = iv_requested val2 = rv_limit ).
    ENDIF.
  ENDMETHOD.

  METHOD describe_json.
    DATA lt_out TYPE string_table.
    APPEND zcl_mcp_json=>pair( iv_key = `status`       iv_raw = zcl_mcp_json=>str( `OK` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `action`       iv_raw = zcl_mcp_json=>str( `DESCRIBE` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `object`       iv_raw = zcl_mcp_json=>str( is_reg-obj_name ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `type`         iv_raw = zcl_mcp_json=>str( `ODATA` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `odataVersion` iv_raw = zcl_mcp_json=>str( is_srv-version ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `entitySet`    iv_raw = zcl_mcp_json=>str( is_srv-entity_set ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `domain`       iv_raw = zcl_mcp_json=>str( is_reg-domain ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `description`  iv_raw = zcl_mcp_json=>str( is_reg-description ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `maxRows`      iv_raw = zcl_mcp_json=>num( effective_limit( is_reg = is_reg iv_requested = 0 ) ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `mandatoryFilters`
                               iv_raw = zcl_mcp_json=>str_array( zcl_mcp_registry=>split_list( is_reg-mandatory_filters ) ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `fields`       iv_raw = iv_fields_json ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `hint`         iv_raw = zcl_mcp_json=>str(
      `Use queryData with these property names. Joins are not supported for OData; chain queries instead. ` &&
      `Dates as YYYY-MM-DD.` ) ) TO lt_out.
    rv_json = zcl_mcp_json=>object( lt_out ).
  ENDMETHOD.

  METHOD query_json.
    DATA lt_out TYPE string_table.
    APPEND zcl_mcp_json=>pair( iv_key = `status`    iv_raw = zcl_mcp_json=>str( `OK` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `action`    iv_raw = zcl_mcp_json=>str( `QUERY` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `source`    iv_raw = zcl_mcp_json=>str( is_reg-obj_name ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `columns`   iv_raw = iv_columns_json ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `rows`      iv_raw = iv_rows_json ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `rowCount`  iv_raw = zcl_mcp_json=>num( iv_count ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `truncated` iv_raw = zcl_mcp_json=>bool( iv_truncated ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `nextOffset`
                               iv_raw = COND string( WHEN iv_truncated = abap_true
                                                     THEN zcl_mcp_json=>num( iv_next_offset ) ELSE `null` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `message`   iv_raw = zcl_mcp_json=>str( iv_message ) ) TO lt_out.
    rv_json = zcl_mcp_json=>object( lt_out ).
  ENDMETHOD.

  " ===================================================================== V2
  METHOD describe_v2.
    DATA lt_items TYPE string_table.
    DATA lt_pairs TYPE string_table.
    DATA(lt_props) = v2_properties( is_srv = is_srv is_reg = is_reg ).
    LOOP AT lt_props INTO DATA(ls_prop).
      CLEAR lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `name`  iv_raw = zcl_mcp_json=>str( ls_prop-name ) ) TO lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `label` iv_raw = zcl_mcp_json=>str( ls_prop-label ) ) TO lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `type`  iv_raw = zcl_mcp_json=>str( ls_prop-edm_type ) ) TO lt_pairs.
      IF ls_prop-key = abap_true.
        APPEND zcl_mcp_json=>pair( iv_key = `key` iv_raw = `true` ) TO lt_pairs.
      ENDIF.
      APPEND zcl_mcp_json=>object( lt_pairs ) TO lt_items.
    ENDLOOP.
    rv_json = describe_json( is_reg = is_reg is_srv = is_srv iv_fields_json = zcl_mcp_json=>array( lt_items ) ).
  ENDMETHOD.

  METHOD query_v2.
    DATA lt_cols    TYPE tt_prop.
    DATA lt_names   TYPE string_table.
    DATA lt_order   TYPE string_table.
    DATA lt_items   TYPE string_table.
    DATA lt_colj    TYPE string_table.
    DATA lt_rowj    TYPE string_table.
    DATA lt_cells   TYPE string_table.
    DATA lv_ref     TYPE string.
    DATA lv_dir     TYPE string.
    DATA lv_message TYPE string.

    DATA(lt_props) = v2_properties( is_srv = is_srv is_reg = is_reg ).

    " select list
    IF is_args-fields IS INITIAL.
      LOOP AT lt_props INTO DATA(ls_p) TO zif_mcp_types=>c_default_fields.
        APPEND ls_p TO lt_cols.
      ENDLOOP.
      lv_message = |No fields requested; returned the first { lines( lt_cols ) } properties. | &&
                   |Request specific fields for better results.|.
    ELSE.
      LOOP AT is_args-fields INTO DATA(lv_field).
        APPEND v2_find( it_props = lt_props iv_name = lv_field ) TO lt_cols.
      ENDLOOP.
    ENDIF.
    LOOP AT lt_cols INTO DATA(ls_col).
      APPEND ls_col-name TO lt_names.
    ENDLOOP.

    " order by
    IF is_args-order_by IS NOT INITIAL.
      SPLIT is_args-order_by AT ',' INTO TABLE lt_items.
      LOOP AT lt_items INTO DATA(lv_item).
        CLEAR: lv_ref, lv_dir.
        lv_item = condense( lv_item ).
        SPLIT lv_item AT space INTO lv_ref lv_dir.
        DATA(ls_ord) = v2_find( it_props = lt_props iv_name = lv_ref ).
        APPEND |{ ls_ord-name }{ COND string( WHEN to_upper( lv_dir ) CP 'DESC*' THEN ` desc` ELSE ` asc` ) }| TO lt_order.
      ENDLOOP.
    ENDIF.

    " limits
    DATA(lv_limit)  = effective_limit( is_reg = is_reg iv_requested = is_args-max_rows ).
    DATA(lv_offset) = nmax( val1 = 0 val2 = nmin( val1 = is_args-offset val2 = zif_mcp_types=>c_max_offset ) ).
    DATA(lv_top)    = lv_limit + 1.

    DATA(lv_uri) = |/{ is_srv-entity_set }?$format=json&$top={ lv_top }&$skip={ lv_offset }| &&
                   |&$select={ concat_lines_of( table = lt_names sep = `,` ) }|.
    DATA(lv_filter) = v2_filter( it_props = lt_props it_filters = is_args-filters ).
    IF lv_filter IS NOT INITIAL.
      lv_uri = lv_uri && |&$filter={ cl_http_utility=>escape_url( lv_filter ) }|.
    ENDIF.
    IF lt_order IS NOT INITIAL.
      lv_uri = lv_uri && |&$orderby={ cl_http_utility=>escape_url( concat_lines_of( table = lt_order sep = `,` ) ) }|.
    ENDIF.

    DATA(lt_rows) = parse_v2_results( http_get( is_srv = is_srv iv_relative = lv_uri ) ).
    DATA(lv_truncated) = xsdbool( lines( lt_rows ) > lv_limit ).
    IF lv_truncated = abap_true.
      DATA(lv_cut_from) = lv_limit + 1.
      DELETE lt_rows FROM lv_cut_from.
    ENDIF.

    " envelope
    LOOP AT lt_cols INTO ls_col.
      APPEND zcl_mcp_json=>object( VALUE #(
        ( zcl_mcp_json=>pair( iv_key = `name`  iv_raw = zcl_mcp_json=>str( ls_col-name ) ) )
        ( zcl_mcp_json=>pair( iv_key = `label` iv_raw = zcl_mcp_json=>str( ls_col-label ) ) )
        ( zcl_mcp_json=>pair( iv_key = `type`  iv_raw = zcl_mcp_json=>str( ls_col-edm_type ) ) ) ) ) TO lt_colj.
    ENDLOOP.
    LOOP AT lt_rows INTO DATA(lt_row).
      CLEAR lt_cells.
      LOOP AT lt_cols INTO ls_col.
        READ TABLE lt_row INTO DATA(ls_nv) WITH TABLE KEY name = ls_col-name.
        APPEND v2_cell( is_prop = ls_col is_nv = ls_nv iv_found = xsdbool( sy-subrc = 0 ) ) TO lt_cells.
      ENDLOOP.
      APPEND zcl_mcp_json=>array( lt_cells ) TO lt_rowj.
    ENDLOOP.

    rv_json = query_json( is_reg          = is_reg
                          iv_columns_json = zcl_mcp_json=>array( lt_colj )
                          iv_rows_json    = zcl_mcp_json=>array( lt_rowj )
                          iv_count        = lines( lt_rows )
                          iv_truncated    = lv_truncated
                          iv_next_offset  = lv_offset + lv_limit
                          iv_message      = lv_message ).
  ENDMETHOD.

  METHOD v2_properties.
    " Reads property names, EDM types, labels and keys of the entity set's type from $metadata
    DATA lv_off   TYPE i.
    DATA lv_len   TYPE i.
    DATA lt_hits  TYPE match_result_tab.
    DATA lt_keys  TYPE string_table.

    DATA(lv_xml) = http_get( is_srv = is_srv iv_relative = `/$metadata` ).

    FIND REGEX |<EntitySet [^>]*Name="{ is_srv-entity_set }"[^>]*>| IN lv_xml MATCH OFFSET lv_off MATCH LENGTH lv_len.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Entity set { is_srv-entity_set } not found in $metadata of { is_srv-path }.|.
    ENDIF.
    DATA(lv_type) = attr( iv_tag = substring( val = lv_xml off = lv_off len = lv_len ) iv_name = `EntityType` ).
    DATA(lv_dot) = find( val = lv_type sub = `.` occ = -1 ).
    IF lv_dot >= 0.
      lv_type = substring( val = lv_type off = lv_dot + 1 ).
    ENDIF.

    FIND REGEX |<EntityType [^>]*Name="{ lv_type }"| IN lv_xml MATCH OFFSET lv_off.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Entity type { lv_type } not found in $metadata of { is_srv-path }.|.
    ENDIF.
    DATA(lv_end) = find( val = lv_xml sub = `</EntityType>` off = lv_off ).
    IF lv_end < 0.
      lv_end = strlen( lv_xml ).
    ENDIF.
    DATA(lv_block) = substring( val = lv_xml off = lv_off len = lv_end - lv_off ).

    FIND ALL OCCURRENCES OF REGEX `<PropertyRef [^>]*>` IN lv_block RESULTS lt_hits.
    LOOP AT lt_hits INTO DATA(ls_hit).
      APPEND attr( iv_tag = substring( val = lv_block off = ls_hit-offset len = ls_hit-length ) iv_name = `Name` ) TO lt_keys.
    ENDLOOP.

    DATA(lt_hidden) = zcl_mcp_registry=>split_list( is_reg-hidden_fields ).
    FIND ALL OCCURRENCES OF REGEX `<Property [^>]*>` IN lv_block RESULTS lt_hits.
    LOOP AT lt_hits INTO ls_hit.
      DATA(lv_tag)  = substring( val = lv_block off = ls_hit-offset len = ls_hit-length ).
      DATA(lv_name) = attr( iv_tag = lv_tag iv_name = `Name` ).
      IF lv_name IS INITIAL OR line_exists( lt_hidden[ table_line = to_upper( lv_name ) ] ).
        CONTINUE.
      ENDIF.
      APPEND VALUE #( name     = lv_name
                      edm_type = attr( iv_tag = lv_tag iv_name = `Type` )
                      label    = attr( iv_tag = lv_tag iv_name = `sap:label` )
                      key      = xsdbool( line_exists( lt_keys[ table_line = lv_name ] ) ) ) TO rt_props.
    ENDLOOP.
  ENDMETHOD.

  METHOD attr.
    FIND REGEX |\\s{ iv_name }="([^"]*)"| IN iv_tag SUBMATCHES rv_value.
  ENDMETHOD.

  METHOD v2_find.
    DATA(lv_upper) = to_upper( condense( iv_name ) ).
    LOOP AT it_props INTO rs_prop.
      IF to_upper( rs_prop-name ) = lv_upper.
        RETURN.
      ENDIF.
    ENDLOOP.
    RAISE EXCEPTION TYPE zcx_mcp_error
      EXPORTING iv_text = |Property '{ iv_name }' does not exist or is not exposed. Call describeObject.|.
  ENDMETHOD.

  METHOD v2_filter.
    DATA lt_conds TYPE string_table.
    DATA lt_or    TYPE string_table.
    DATA lv_cond  TYPE string.

    LOOP AT it_filters INTO DATA(ls_filter).
      DATA(ls_prop) = v2_find( it_props = it_props iv_name = ls_filter-field ).
      DATA(lv_p)    = ls_prop-name.
      DATA(lv_op)   = to_upper( condense( ls_filter-op ) ).
      IF lv_op IS INITIAL.
        lv_op = `EQ`.
      ENDIF.

      CASE lv_op.
        WHEN `EQ` OR `NE` OR `GT` OR `GE` OR `LT` OR `LE`.
          lv_cond = |{ lv_p } { to_lower( lv_op ) } { v2_literal( is_prop = ls_prop iv_value = ls_filter-value ) }|.
        WHEN `BT`.
          lv_cond = |({ lv_p } ge { v2_literal( is_prop = ls_prop iv_value = ls_filter-low ) } and | &&
                    |{ lv_p } le { v2_literal( is_prop = ls_prop iv_value = ls_filter-high ) })|.
        WHEN `IN`.
          IF ls_filter-values IS INITIAL.
            RAISE EXCEPTION TYPE zcx_mcp_error
              EXPORTING iv_text = |Operator IN needs a non-empty 'values' array (field { ls_filter-field }).|.
          ENDIF.
          CLEAR lt_or.
          LOOP AT ls_filter-values INTO DATA(lv_val).
            APPEND |{ lv_p } eq { v2_literal( is_prop = ls_prop iv_value = lv_val ) }| TO lt_or.
          ENDLOOP.
          lv_cond = |({ concat_lines_of( table = lt_or sep = ` or ` ) })|.
        WHEN `CP`.
          " abc* -> startswith, *abc -> endswith, *abc* -> substringof
          DATA(lv_pat)  = shift_left( shift_right( ls_filter-value ) ).
          DATA(lv_core) = lv_pat.
          REPLACE ALL OCCURRENCES OF `*` IN lv_core WITH ``.
          DATA(lv_lit)   = v2_literal( is_prop = VALUE #( edm_type = `Edm.String` ) iv_value = lv_core ).
          DATA(lv_plen)  = strlen( lv_pat ).
          DATA(lv_first) = COND string( WHEN lv_plen > 0 THEN substring( val = lv_pat len = 1 ) ).
          DATA(lv_last)  = COND string( WHEN lv_plen > 0 THEN substring( val = lv_pat off = lv_plen - 1 len = 1 ) ).
          IF lv_first = `*` AND lv_last = `*`.
            lv_cond = |substringof({ lv_lit },{ lv_p }) eq true|.
          ELSEIF lv_last = `*`.
            lv_cond = |startswith({ lv_p },{ lv_lit }) eq true|.
          ELSEIF lv_first = `*`.
            lv_cond = |endswith({ lv_p },{ lv_lit }) eq true|.
          ELSE.
            lv_cond = |{ lv_p } eq { lv_lit }|.
          ENDIF.
        WHEN OTHERS.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Unsupported operator '{ lv_op }'. Use EQ, NE, GT, GE, LT, LE, BT, IN or CP.|.
      ENDCASE.
      APPEND lv_cond TO lt_conds.
    ENDLOOP.

    rv_filter = concat_lines_of( table = lt_conds sep = ` and ` ).
  ENDMETHOD.

  METHOD v2_literal.
    DATA(lv_value) = shift_left( shift_right( iv_value ) ).

    CASE is_prop-edm_type.
      WHEN `Edm.DateTime` OR `Edm.DateTimeOffset`.
        REPLACE ALL OCCURRENCES OF `-` IN lv_value WITH ``.
        IF strlen( lv_value ) <> 8 OR lv_value CN '0123456789'.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Date '{ iv_value }' for { is_prop-name } must be YYYY-MM-DD.|.
        ENDIF.
        DATA(lv_iso) = |{ lv_value(4) }-{ lv_value+4(2) }-{ lv_value+6(2) }T00:00:00|.
        rv_lit = COND #( WHEN is_prop-edm_type = `Edm.DateTime` THEN |datetime'{ lv_iso }'|
                         ELSE |datetimeoffset'{ lv_iso }Z'| ).
      WHEN `Edm.Decimal` OR `Edm.Double` OR `Edm.Single`
        OR `Edm.Int16` OR `Edm.Int32` OR `Edm.Int64` OR `Edm.Byte` OR `Edm.SByte`.
        FIND REGEX '^-?\d+(\.\d+)?$' IN lv_value.
        IF sy-subrc <> 0.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Value '{ iv_value }' is not numeric for { is_prop-name }.|.
        ENDIF.
        rv_lit = COND #( WHEN is_prop-edm_type = `Edm.Decimal` THEN |{ lv_value }M| ELSE lv_value ).
      WHEN `Edm.Boolean`.
        rv_lit = COND #( WHEN to_lower( lv_value ) = `true` OR lv_value = `X` THEN `true` ELSE `false` ).
      WHEN `Edm.Guid`.
        rv_lit = |guid'{ lv_value }'|.
      WHEN `Edm.Time`.
        REPLACE ALL OCCURRENCES OF `:` IN lv_value WITH ``.
        rv_lit = |time'PT{ substring( val = lv_value len = 2 ) }H{ substring( val = lv_value off = 2 len = 2 ) }M| &&
                 |{ substring( val = lv_value off = 4 len = 2 ) }S'|.
      WHEN OTHERS.
        REPLACE ALL OCCURRENCES OF `'` IN lv_value WITH `''`.
        rv_lit = |'{ lv_value }'|.
    ENDCASE.
  ENDMETHOD.

  METHOD v2_cell.
    DATA lv_ms_text TYPE string.
    DATA lv_ms      TYPE p LENGTH 16 DECIMALS 0.
    DATA lv_date    TYPE d VALUE '19700101'.

    IF iv_found = abap_false OR is_nv-is_null = abap_true.
      rv_json = `null`.
      RETURN.
    ENDIF.

    CASE is_prop-edm_type.
      WHEN `Edm.DateTime` OR `Edm.DateTimeOffset`.
        FIND REGEX '/Date\((-?\d+)' IN is_nv-value SUBMATCHES lv_ms_text.
        IF sy-subrc = 0.
          lv_ms = lv_ms_text.
          lv_date = lv_date + lv_ms DIV 86400000.
          rv_json = zcl_mcp_json=>str( |{ lv_date(4) }-{ lv_date+4(2) }-{ lv_date+6(2) }| ).
        ELSE.
          rv_json = zcl_mcp_json=>str( is_nv-value ).
        ENDIF.
      WHEN `Edm.Decimal` OR `Edm.Double` OR `Edm.Single`
        OR `Edm.Int16` OR `Edm.Int32` OR `Edm.Int64` OR `Edm.Byte` OR `Edm.SByte`.
        FIND REGEX '^-?\d+(\.\d+)?([eE][-+]?\d+)?$' IN is_nv-value.
        rv_json = COND #( WHEN sy-subrc = 0 THEN is_nv-value ELSE zcl_mcp_json=>str( is_nv-value ) ).
      WHEN `Edm.Boolean`.
        rv_json = COND #( WHEN to_lower( is_nv-value ) = `true` THEN `true` ELSE `false` ).
      WHEN OTHERS.
        rv_json = zcl_mcp_json=>str( is_nv-value ).
    ENDCASE.
  ENDMETHOD.

  METHOD http_get.
    DATA lo_client TYPE REF TO if_http_client.
    DATA lv_code   TYPE i.
    DATA lv_dest   TYPE rfcdest.

    lv_dest = is_srv-destination.
    cl_http_client=>create_by_destination(
      EXPORTING  destination = lv_dest
      IMPORTING  client      = lo_client
      EXCEPTIONS OTHERS      = 1 ).
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |HTTP destination { lv_dest } could not be opened (SM59).|.
    ENDIF.

    cl_http_utility=>set_request_uri( request = lo_client->request uri = |{ is_srv-path }{ iv_relative }| ).
    lo_client->request->set_method( 'GET' ).
    lo_client->send( EXCEPTIONS OTHERS = 1 ).
    IF sy-subrc = 0.
      lo_client->receive( EXCEPTIONS OTHERS = 1 ).
    ENDIF.
    IF sy-subrc <> 0.
      lo_client->close( ).
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |OData call to { is_srv-path } failed (communication error, check { lv_dest }).|.
    ENDIF.

    lo_client->response->get_status( IMPORTING code = lv_code ).
    rv_body = lo_client->response->get_cdata( ).
    lo_client->close( ).

    IF lv_code >= 400.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |OData service returned HTTP { lv_code }: | &&
                            |{ substring( val = rv_body len = nmin( val1 = 300 val2 = strlen( rv_body ) ) ) }|.
    ENDIF.
  ENDMETHOD.

  METHOD parse_v2_results.
    " Walks the JSON (as sXML events) and collects the flat properties of each d.results[] entry.
    " Nested objects/arrays (__metadata, navigation properties) are skipped.
    DATA lv_depth         TYPE i.
    DATA lv_results_depth TYPE i VALUE -1.
    DATA lv_skip_depth    TYPE i VALUE -1.
    DATA lv_capture       TYPE abap_bool.
    DATA lv_capture_elem  TYPE string.
    DATA lv_name          TYPE string.
    DATA lt_row           TYPE tt_nv.

    TRY.
        DATA(lo_reader) = cl_sxml_string_reader=>create( cl_abap_codepage=>convert_to( iv_json ) ).
        DO.
          DATA(lo_node) = lo_reader->read_next_node( ).
          IF lo_node IS NOT BOUND.
            EXIT.
          ENDIF.

          CASE lo_node->type.
            WHEN if_sxml_node=>co_nt_element_open.
              lv_depth = lv_depth + 1.
              IF lv_skip_depth >= 0.
                CONTINUE.
              ENDIF.
              DATA(lo_open) = CAST if_sxml_open_element( lo_node ).
              DATA(lv_elem) = CONV string( lo_open->qname-name ).
              DATA(lo_attr) = lo_open->get_attribute_value( 'name' ).
              lv_name = COND #( WHEN lo_attr IS BOUND THEN lo_attr->get_value( ) ELSE `` ).

              IF lv_results_depth < 0.
                IF lv_elem = `array` AND lv_name = `results`.
                  lv_results_depth = lv_depth.
                ENDIF.
              ELSEIF lv_depth = lv_results_depth + 1 AND lv_elem = `object`.
                CLEAR lt_row.
              ELSEIF lv_depth = lv_results_depth + 2.
                IF lv_elem = `object` OR lv_elem = `array`.
                  lv_skip_depth = lv_depth.
                ELSE.
                  lv_capture      = abap_true.
                  lv_capture_elem = lv_elem.
                ENDIF.
              ENDIF.

            WHEN if_sxml_node=>co_nt_value.
              IF lv_capture = abap_true AND lv_skip_depth < 0.
                INSERT VALUE #( name = lv_name value = CAST if_sxml_value_node( lo_node )->get_value( ) )
                  INTO TABLE lt_row.
                lv_capture = abap_false.
              ENDIF.

            WHEN if_sxml_node=>co_nt_element_close.
              IF lv_skip_depth >= 0.
                IF lv_skip_depth = lv_depth.
                  lv_skip_depth = -1.
                ENDIF.
              ELSE.
                IF lv_capture = abap_true.        " empty string or null
                  INSERT VALUE #( name = lv_name value = `` is_null = xsdbool( lv_capture_elem = `null` ) )
                    INTO TABLE lt_row.
                  lv_capture = abap_false.
                ENDIF.
                IF lv_results_depth >= 0 AND lv_depth = lv_results_depth + 1.
                  APPEND lt_row TO rt_rows.
                ELSEIF lv_depth = lv_results_depth.
                  lv_results_depth = -1.
                ENDIF.
              ENDIF.
              lv_depth = lv_depth - 1.
          ENDCASE.
        ENDDO.
      CATCH cx_sxml_error INTO DATA(lx_xml).
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text  = |Cannot parse OData response: { lx_xml->get_text( ) }|
                    previous = lx_xml.
    ENDTRY.
  ENDMETHOD.

ENDCLASS.
