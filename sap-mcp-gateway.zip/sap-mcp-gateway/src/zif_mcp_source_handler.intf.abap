"! Contract for one source type (TABLE/CDS, BAPI/FM, later ODATA ...).
"! Each method returns the complete JSON envelope for its action.
INTERFACE zif_mcp_source_handler PUBLIC.

  METHODS describe
    IMPORTING is_reg         TYPE zmcp_registry
    RETURNING VALUE(rv_json) TYPE string
    RAISING   zcx_mcp_error.

  METHODS query
    IMPORTING is_reg         TYPE zmcp_registry
              is_args        TYPE zif_mcp_types=>ty_query_args
    RETURNING VALUE(rv_json) TYPE string
    RAISING   zcx_mcp_error.

  METHODS execute
    IMPORTING is_reg         TYPE zmcp_registry
              iv_params_json TYPE string
    RETURNING VALUE(rv_json) TYPE string
    RAISING   zcx_mcp_error.

ENDINTERFACE.
