"! Handler for BAPI and FM objects (read-only functions registered in ZMCP_REGISTRY).
"! Interface is read with FUNCTION_IMPORT_INTERFACE, parameters are filled from the
"! "params" JSON object (keys = parameter names, uppercase), the function is called
"! dynamically and ROLLBACK WORK is always executed afterwards.
CLASS zcl_mcp_func_handler DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES zif_mcp_source_handler.
  PRIVATE SECTION.
    CONSTANTS c_max_rows TYPE i VALUE 500.
    TYPES: BEGIN OF ty_param,
             name     TYPE string,
             kind     TYPE string,      " import | export | changing | tables
             typename TYPE string,
             optional TYPE abap_bool,
             default  TYPE string,
             text     TYPE string,
           END OF ty_param,
           tt_param TYPE STANDARD TABLE OF ty_param WITH EMPTY KEY.

    METHODS get_interface
      IMPORTING iv_name       TYPE csequence
      EXPORTING et_params     TYPE tt_param
                et_exceptions TYPE string_table
      RAISING   zcx_mcp_error.
    METHODS get_type
      IMPORTING is_param       TYPE ty_param
      RETURNING VALUE(ro_type) TYPE REF TO cl_abap_datadescr
      RAISING   zcx_mcp_error.
    METHODS fields_json
      IMPORTING io_type        TYPE REF TO cl_abap_datadescr
      RETURNING VALUE(rv_json) TYPE string.
    METHODS output_json
      IMPORTING iv_name     TYPE string
                ir_data     TYPE REF TO data
      EXPORTING ev_json     TYPE string
                ev_is_value TYPE abap_bool.
    METHODS result_set
      IMPORTING iv_name        TYPE string
                io_struct      TYPE REF TO cl_abap_structdescr
                it_data        TYPE ANY TABLE
      RETURNING VALUE(rv_json) TYPE string.
    METHODS collect_errors
      IMPORTING ir_data     TYPE REF TO data
      CHANGING  ct_messages TYPE string_table.
    METHODS add_message
      IMPORTING is_row      TYPE any
      CHANGING  ct_messages TYPE string_table.
ENDCLASS.

CLASS zcl_mcp_func_handler IMPLEMENTATION.

  " ===================================================================== DESCRIBE
  METHOD zif_mcp_source_handler~describe.
    DATA lt_param_json TYPE string_table.
    DATA lt_pp         TYPE string_table.
    DATA lt_out        TYPE string_table.

    get_interface( EXPORTING iv_name = is_reg-obj_name
                   IMPORTING et_params = DATA(lt_params) et_exceptions = DATA(lt_exc) ).

    LOOP AT lt_params INTO DATA(ls_p).
      CLEAR lt_pp.
      APPEND zcl_mcp_json=>pair( iv_key = `name` iv_raw = zcl_mcp_json=>str( ls_p-name ) ) TO lt_pp.
      APPEND zcl_mcp_json=>pair( iv_key = `kind` iv_raw = zcl_mcp_json=>str( ls_p-kind ) ) TO lt_pp.
      APPEND zcl_mcp_json=>pair( iv_key = `type` iv_raw = zcl_mcp_json=>str( ls_p-typename ) ) TO lt_pp.
      IF ls_p-kind <> `export`.
        APPEND zcl_mcp_json=>pair( iv_key = `optional` iv_raw = zcl_mcp_json=>bool( ls_p-optional ) ) TO lt_pp.
      ENDIF.
      IF ls_p-default IS NOT INITIAL.
        APPEND zcl_mcp_json=>pair( iv_key = `default` iv_raw = zcl_mcp_json=>str( ls_p-default ) ) TO lt_pp.
      ENDIF.
      APPEND zcl_mcp_json=>pair( iv_key = `description` iv_raw = zcl_mcp_json=>str( ls_p-text ) ) TO lt_pp.
      TRY.
          DATA(lv_fields) = fields_json( get_type( ls_p ) ).
          IF lv_fields IS NOT INITIAL.
            APPEND zcl_mcp_json=>pair( iv_key = `fields` iv_raw = lv_fields ) TO lt_pp.
          ENDIF.
        CATCH zcx_mcp_error.
          " type not resolvable -> describe without fields
      ENDTRY.
      APPEND zcl_mcp_json=>object( lt_pp ) TO lt_param_json.
    ENDLOOP.

    APPEND zcl_mcp_json=>pair( iv_key = `status`       iv_raw = zcl_mcp_json=>str( `OK` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `action`       iv_raw = zcl_mcp_json=>str( `DESCRIBE` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `object`       iv_raw = zcl_mcp_json=>str( is_reg-obj_name ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `type`         iv_raw = zcl_mcp_json=>str( is_reg-obj_type ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `description`  iv_raw = zcl_mcp_json=>str( is_reg-description ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `returnTables`
                               iv_raw = zcl_mcp_json=>str_array( zcl_mcp_registry=>split_list( is_reg-return_tables ) ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `parameters`   iv_raw = zcl_mcp_json=>array( lt_param_json ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `exceptions`   iv_raw = zcl_mcp_json=>str_array( lt_exc ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `hint` iv_raw = zcl_mcp_json=>str(
      `Use callFunction. Put import, changing and tables parameters into params using the ` &&
      `parameter names above (uppercase). Structures and table rows use the listed field names.` ) ) TO lt_out.
    rv_json = zcl_mcp_json=>object( lt_out ).
  ENDMETHOD.

  METHOD zif_mcp_source_handler~query.
    RAISE EXCEPTION TYPE zcx_mcp_error
      EXPORTING iv_text = |{ is_reg-obj_name } is a { is_reg-obj_type }. Use callFunction instead of queryData.|.
  ENDMETHOD.

  " ===================================================================== CALL
  METHOD zif_mcp_source_handler~execute.
    DATA lt_comp     TYPE cl_abap_structdescr=>component_table.
    DATA lr_input    TYPE REF TO data.
    DATA lt_parm     TYPE abap_func_parmbind_tab.
    DATA ls_bind     TYPE abap_func_parmbind.
    DATA lt_excp     TYPE abap_func_excpbind_tab.
    DATA lt_missing  TYPE string_table.
    DATA lt_sets     TYPE string_table.
    DATA lt_values   TYPE string_table.
    DATA lt_messages TYPE string_table.
    DATA lt_out      TYPE string_table.
    DATA lv_json     TYPE string.
    DATA lv_is_value TYPE abap_bool.
    DATA lv_msg_text TYPE string.
    FIELD-SYMBOLS <ls_input> TYPE any.
    FIELD-SYMBOLS <lv_comp>  TYPE any.

    DATA(lv_fname) = to_upper( CONV string( is_reg-obj_name ) ).
    get_interface( EXPORTING iv_name = lv_fname
                   IMPORTING et_params = DATA(lt_params) et_exceptions = DATA(lt_exc_names) ).

    " 1. dynamic input structure: one component per import / changing / tables parameter
    LOOP AT lt_params INTO DATA(ls_p) WHERE kind <> `export`.
      APPEND VALUE #( name = ls_p-name type = get_type( ls_p ) ) TO lt_comp.
    ENDLOOP.
    IF lt_comp IS NOT INITIAL.
      DATA(lo_input) = cl_abap_structdescr=>create( lt_comp ).
      CREATE DATA lr_input TYPE HANDLE lo_input.
      ASSIGN lr_input->* TO <ls_input>.
      IF iv_params_json IS NOT INITIAL.
        /ui2/cl_json=>deserialize( EXPORTING json        = iv_params_json
                                             pretty_name = /ui2/cl_json=>pretty_mode-none
                                   CHANGING  data        = <ls_input> ).
      ENDIF.
    ENDIF.

    " 2. parameter binding (FM view: import = our EXPORTING, export = our IMPORTING)
    LOOP AT lt_params INTO ls_p.
      CLEAR ls_bind.
      ls_bind-name = ls_p-name.
      IF ls_p-kind = `export`.
        DATA(lo_out_type) = get_type( ls_p ).
        CREATE DATA ls_bind-value TYPE HANDLE lo_out_type.
        ls_bind-kind = abap_func_importing.
      ELSE.
        ASSIGN COMPONENT ls_p-name OF STRUCTURE <ls_input> TO <lv_comp>.
        IF ls_p-kind = `import` AND <lv_comp> IS INITIAL.
          IF ls_p-optional = abap_false AND ls_p-default IS INITIAL.
            APPEND ls_p-name TO lt_missing.
          ENDIF.
          CONTINUE.                                 " not supplied -> FM default applies
        ENDIF.
        GET REFERENCE OF <lv_comp> INTO ls_bind-value.
        ls_bind-kind = SWITCH #( ls_p-kind WHEN `import`   THEN abap_func_exporting
                                           WHEN `changing` THEN abap_func_changing
                                           ELSE abap_func_tables ).
      ENDIF.
      INSERT ls_bind INTO TABLE lt_parm.
    ENDLOOP.

    IF lt_missing IS NOT INITIAL.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Missing required parameter(s): { concat_lines_of( table = lt_missing sep = `, ` ) }. | &&
                            |Call describeObject for { lv_fname }.|.
    ENDIF.

    " 3. exceptions
    LOOP AT lt_exc_names INTO DATA(lv_exc).
      INSERT VALUE #( name = lv_exc value = sy-tabix ) INTO TABLE lt_excp.
    ENDLOOP.
    INSERT VALUE #( name = 'ERROR_MESSAGE' value = 98 ) INTO TABLE lt_excp.
    INSERT VALUE #( name = 'OTHERS'        value = 99 ) INTO TABLE lt_excp.

    " 4. call (read-only functions only; never committed)
    TRY.
        CALL FUNCTION lv_fname PARAMETER-TABLE lt_parm EXCEPTION-TABLE lt_excp.
      CATCH cx_sy_dyn_call_error INTO DATA(lx_call).
        ROLLBACK WORK.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text  = |Call of { lv_fname } failed: { lx_call->get_text( ) }|
                    previous = lx_call.
    ENDTRY.
    DATA(lv_subrc) = sy-subrc.
    IF lv_subrc <> 0 AND sy-msgid IS NOT INITIAL.
      MESSAGE ID sy-msgid TYPE 'I' NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO lv_msg_text.
    ENDIF.
    ROLLBACK WORK.          " discard any DB change or update task the function may have registered

    IF lv_subrc <> 0.
      DATA(lv_exc_name) = COND string( WHEN lv_subrc = 98 THEN `ERROR_MESSAGE`
                                       WHEN lv_subrc = 99 THEN `OTHERS`
                                       ELSE VALUE #( lt_exc_names[ lv_subrc ] OPTIONAL ) ).
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |{ lv_fname } raised exception { lv_exc_name }| &&
                            COND string( WHEN lv_msg_text IS NOT INITIAL THEN |: { lv_msg_text }| ).
    ENDIF.

    " 5. outputs (RETURN_TABLES from the registry, or everything if blank)
    DATA(lt_return) = zcl_mcp_registry=>split_list( is_reg-return_tables ).
    LOOP AT lt_parm INTO ls_bind
         WHERE kind = abap_func_importing OR kind = abap_func_tables OR kind = abap_func_changing.
      DATA(lv_pname) = CONV string( ls_bind-name ).
      IF lv_pname = `RETURN`.
        collect_errors( EXPORTING ir_data = ls_bind-value CHANGING ct_messages = lt_messages ).
      ENDIF.
      IF lt_return IS NOT INITIAL AND lv_pname <> `RETURN`
         AND NOT line_exists( lt_return[ table_line = lv_pname ] ).
        CONTINUE.
      ENDIF.
      output_json( EXPORTING iv_name = lv_pname ir_data = ls_bind-value
                   IMPORTING ev_json = lv_json ev_is_value = lv_is_value ).
      IF lv_json IS INITIAL.
        CONTINUE.
      ENDIF.
      IF lv_is_value = abap_true.
        APPEND lv_json TO lt_values.
      ELSE.
        APPEND lv_json TO lt_sets.
      ENDIF.
    ENDLOOP.

    APPEND zcl_mcp_json=>pair( iv_key = `status`
                               iv_raw = zcl_mcp_json=>str( COND string( WHEN lt_messages IS INITIAL THEN `OK` ELSE `ERROR` ) ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `action`     iv_raw = zcl_mcp_json=>str( `CALL` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `object`     iv_raw = zcl_mcp_json=>str( lv_fname ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `message`
                               iv_raw = zcl_mcp_json=>str( concat_lines_of( table = lt_messages sep = ` | ` ) ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `values`     iv_raw = zcl_mcp_json=>object( lt_values ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `resultSets` iv_raw = zcl_mcp_json=>array( lt_sets ) ) TO lt_out.
    rv_json = zcl_mcp_json=>object( lt_out ).
  ENDMETHOD.

  " ===================================================================== helpers
  METHOD get_interface.
    DATA lt_exc  TYPE STANDARD TABLE OF rsexc.
    DATA lt_exp  TYPE STANDARD TABLE OF rsexp.
    DATA lt_imp  TYPE STANDARD TABLE OF rsimp.
    DATA lt_cha  TYPE STANDARD TABLE OF rscha.
    DATA lt_tbl  TYPE STANDARD TABLE OF rstbl.
    DATA lt_doc  TYPE STANDARD TABLE OF funct.
    DATA lv_name TYPE rs38l-name.

    CLEAR: et_params, et_exceptions.
    lv_name = to_upper( iv_name ).

    CALL FUNCTION 'FUNCTION_IMPORT_INTERFACE'
      EXPORTING
        funcname           = lv_name
      TABLES
        exception_list     = lt_exc
        export_parameter   = lt_exp
        import_parameter   = lt_imp
        changing_parameter = lt_cha
        tables_parameter   = lt_tbl
        p_docu             = lt_doc
      EXCEPTIONS
        function_not_found = 1
        OTHERS             = 2.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Function { lv_name } not found.|.
    ENDIF.

    LOOP AT lt_imp INTO DATA(ls_imp).
      APPEND VALUE #( name = ls_imp-parameter kind = `import`
                      typename = COND string( WHEN ls_imp-typ IS NOT INITIAL THEN ls_imp-typ ELSE ls_imp-dbfield )
                      optional = ls_imp-optional default = ls_imp-default ) TO et_params.
    ENDLOOP.
    LOOP AT lt_cha INTO DATA(ls_cha).
      APPEND VALUE #( name = ls_cha-parameter kind = `changing`
                      typename = COND string( WHEN ls_cha-typ IS NOT INITIAL THEN ls_cha-typ ELSE ls_cha-dbfield )
                      optional = ls_cha-optional default = ls_cha-default ) TO et_params.
    ENDLOOP.
    LOOP AT lt_tbl INTO DATA(ls_tbl).
      APPEND VALUE #( name = ls_tbl-parameter kind = `tables`
                      typename = COND string( WHEN ls_tbl-typ IS NOT INITIAL THEN ls_tbl-typ ELSE ls_tbl-dbstruct )
                      optional = ls_tbl-optional ) TO et_params.
    ENDLOOP.
    LOOP AT lt_exp INTO DATA(ls_exp).
      APPEND VALUE #( name = ls_exp-parameter kind = `export`
                      typename = COND string( WHEN ls_exp-typ IS NOT INITIAL THEN ls_exp-typ ELSE ls_exp-dbfield ) )
        TO et_params.
    ENDLOOP.

    LOOP AT et_params ASSIGNING FIELD-SYMBOL(<ls_param>).
      READ TABLE lt_doc INTO DATA(ls_doc) WITH KEY parameter = <ls_param>-name.
      IF sy-subrc = 0.
        <ls_param>-text = ls_doc-stext.
      ENDIF.
    ENDLOOP.

    LOOP AT lt_exc INTO DATA(ls_exc).
      APPEND CONV string( ls_exc-exception ) TO et_exceptions.
    ENDLOOP.
  ENDMETHOD.

  METHOD get_type.
    DATA lo_type TYPE REF TO cl_abap_typedescr.

    IF is_param-typename IS INITIAL.
      ro_type = cl_abap_elemdescr=>get_string( ).   " untyped parameter
      RETURN.
    ENDIF.

    cl_abap_typedescr=>describe_by_name(
      EXPORTING  p_name         = is_param-typename
      RECEIVING  p_descr_ref    = lo_type
      EXCEPTIONS type_not_found = 1
                 OTHERS         = 2 ).
    IF sy-subrc <> 0 OR lo_type->kind = cl_abap_typedescr=>kind_class
                     OR lo_type->kind = cl_abap_typedescr=>kind_intf.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Cannot resolve type { is_param-typename } of parameter { is_param-name }.|.
    ENDIF.

    IF is_param-kind = `tables` AND lo_type->kind = cl_abap_typedescr=>kind_struct.
      ro_type = cl_abap_tabledescr=>create( p_line_type = CAST cl_abap_datadescr( lo_type ) ).
    ELSE.
      ro_type = CAST cl_abap_datadescr( lo_type ).
    ENDIF.
  ENDMETHOD.

  METHOD fields_json.
    DATA lo_struct TYPE REF TO cl_abap_structdescr.
    DATA lt_items  TYPE string_table.

    CASE io_type->kind.
      WHEN cl_abap_typedescr=>kind_struct.
        lo_struct = CAST #( io_type ).
      WHEN cl_abap_typedescr=>kind_table.
        DATA(lo_line) = CAST cl_abap_tabledescr( io_type )->get_table_line_type( ).
        IF lo_line->kind = cl_abap_typedescr=>kind_struct.
          lo_struct = CAST #( lo_line ).
        ENDIF.
    ENDCASE.
    IF lo_struct IS NOT BOUND.
      RETURN.
    ENDIF.

    DATA(lt_cols) = zcl_mcp_envelope=>cols_from_struct( lo_struct ).
    LOOP AT lt_cols INTO DATA(ls_col).
      APPEND zcl_mcp_json=>object( VALUE #(
        ( zcl_mcp_json=>pair( iv_key = `name`  iv_raw = zcl_mcp_json=>str( ls_col-name ) ) )
        ( zcl_mcp_json=>pair( iv_key = `label` iv_raw = zcl_mcp_json=>str( ls_col-label ) ) ) ) ) TO lt_items.
      IF lines( lt_items ) >= 40.
        EXIT.
      ENDIF.
    ENDLOOP.
    rv_json = zcl_mcp_json=>array( lt_items ).
  ENDMETHOD.

  METHOD output_json.
    DATA lr_tab TYPE REF TO data.
    FIELD-SYMBOLS <lv_data> TYPE any.
    FIELD-SYMBOLS <lt_tab>  TYPE ANY TABLE.

    CLEAR: ev_json, ev_is_value.
    ASSIGN ir_data->* TO <lv_data>.
    DATA(lo_type) = cl_abap_typedescr=>describe_by_data( <lv_data> ).

    CASE lo_type->kind.
      WHEN cl_abap_typedescr=>kind_elem.
        DATA(ls_col) = VALUE zif_mcp_types=>ty_col( inttype = lo_type->type_kind ).
        ev_json = zcl_mcp_json=>pair( iv_key = iv_name
                                      iv_raw = zcl_mcp_envelope=>cell( iv_value = <lv_data> is_col = ls_col ) ).
        ev_is_value = abap_true.

      WHEN cl_abap_typedescr=>kind_struct.
        DATA(lo_struct) = CAST cl_abap_structdescr( lo_type ).
        DATA(lo_tab_type) = cl_abap_tabledescr=>create( p_line_type = lo_struct ).
        CREATE DATA lr_tab TYPE HANDLE lo_tab_type.
        ASSIGN lr_tab->* TO <lt_tab>.
        INSERT <lv_data> INTO TABLE <lt_tab>.
        ev_json = result_set( iv_name = iv_name io_struct = lo_struct it_data = <lt_tab> ).

      WHEN cl_abap_typedescr=>kind_table.
        ASSIGN <lv_data> TO <lt_tab>.
        DATA(lo_line) = CAST cl_abap_tabledescr( lo_type )->get_table_line_type( ).
        IF lo_line->kind = cl_abap_typedescr=>kind_struct.
          ev_json = result_set( iv_name = iv_name io_struct = CAST #( lo_line ) it_data = <lt_tab> ).
        ENDIF.
    ENDCASE.
  ENDMETHOD.

  METHOD result_set.
    DATA(lt_cols)  = zcl_mcp_envelope=>cols_from_struct( io_struct ).
    DATA(lv_count) = lines( it_data ).
    rv_json = zcl_mcp_json=>object( VALUE #(
      ( zcl_mcp_json=>pair( iv_key = `name`      iv_raw = zcl_mcp_json=>str( iv_name ) ) )
      ( zcl_mcp_json=>pair( iv_key = `columns`   iv_raw = zcl_mcp_envelope=>columns( lt_cols ) ) )
      ( zcl_mcp_json=>pair( iv_key = `rows`      iv_raw = zcl_mcp_envelope=>rows( it_data = it_data
                                                                                 it_cols = lt_cols
                                                                                 iv_max  = c_max_rows ) ) )
      ( zcl_mcp_json=>pair( iv_key = `rowCount`  iv_raw = zcl_mcp_json=>num( nmin( val1 = lv_count val2 = c_max_rows ) ) ) )
      ( zcl_mcp_json=>pair( iv_key = `truncated` iv_raw = zcl_mcp_json=>bool( xsdbool( lv_count > c_max_rows ) ) ) ) ) ).
  ENDMETHOD.

  METHOD collect_errors.
    FIELD-SYMBOLS <lv_data> TYPE any.
    FIELD-SYMBOLS <lt_tab>  TYPE ANY TABLE.
    FIELD-SYMBOLS <ls_row>  TYPE any.

    ASSIGN ir_data->* TO <lv_data>.
    DATA(lo_type) = cl_abap_typedescr=>describe_by_data( <lv_data> ).
    CASE lo_type->kind.
      WHEN cl_abap_typedescr=>kind_table.
        ASSIGN <lv_data> TO <lt_tab>.
        LOOP AT <lt_tab> ASSIGNING <ls_row>.
          add_message( EXPORTING is_row = <ls_row> CHANGING ct_messages = ct_messages ).
        ENDLOOP.
      WHEN cl_abap_typedescr=>kind_struct.
        add_message( EXPORTING is_row = <lv_data> CHANGING ct_messages = ct_messages ).
    ENDCASE.
  ENDMETHOD.

  METHOD add_message.
    FIELD-SYMBOLS <lv_type> TYPE any.
    FIELD-SYMBOLS <lv_msg>  TYPE any.

    ASSIGN COMPONENT 'TYPE' OF STRUCTURE is_row TO <lv_type>.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.
    ASSIGN COMPONENT 'MESSAGE' OF STRUCTURE is_row TO <lv_msg>.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.
    IF <lv_type> = 'E' OR <lv_type> = 'A'.
      APPEND CONV string( <lv_msg> ) TO ct_messages.
    ENDIF.
  ENDMETHOD.

ENDCLASS.
