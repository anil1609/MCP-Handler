"! DDIC metadata for tables / views / CDS entities and relation handling.
"! Relations are derived automatically: a field of object A that has the same
"! domain as the leading key field(s) of object B can be joined to B.
"! RELATIONS in the registry can add links the DDIC does not reveal.
CLASS zcl_mcp_metadata DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    CLASS-METHODS get_fields
      IMPORTING iv_name          TYPE csequence
      RETURNING VALUE(rt_fields) TYPE zif_mcp_types=>tt_dfies
      RAISING   zcx_mcp_error.
    CLASS-METHODS leading_key
      IMPORTING it_fields       TYPE zif_mcp_types=>tt_dfies
      RETURNING VALUE(rs_field) TYPE dfies.
    "! 'EKPO:EBELN=EBELN;LFA1:LIFNR=LIFNR' -> relation table
    CLASS-METHODS parse_relations
      IMPORTING iv_text       TYPE csequence
      RETURNING VALUE(rt_rel) TYPE zif_mcp_types=>tt_relation.
    "! Configured + derived relations from is_reg to other active registry objects
    CLASS-METHODS get_relations
      IMPORTING is_reg        TYPE zmcp_registry
                it_regs       TYPE zif_mcp_types=>tt_registry
      RETURNING VALUE(rt_rel) TYPE zif_mcp_types=>tt_relation.
    CLASS-METHODS is_join_allowed
      IMPORTING is_left_reg    TYPE zmcp_registry
                is_left_field  TYPE dfies
                is_right_reg   TYPE zmcp_registry
                is_right_field TYPE dfies
      RETURNING VALUE(rv_ok)   TYPE abap_bool.
  PRIVATE SECTION.
    TYPES: BEGIN OF ty_cache,
             name   TYPE string,
             fields TYPE zif_mcp_types=>tt_dfies,
           END OF ty_cache.
    CLASS-DATA gt_cache TYPE HASHED TABLE OF ty_cache WITH UNIQUE KEY name.
    CLASS-METHODS is_joinable_type
      IMPORTING is_field     TYPE dfies
      RETURNING VALUE(rv_ok) TYPE abap_bool.
    CLASS-METHODS has_pair
      IMPORTING it_rel       TYPE zif_mcp_types=>tt_relation
                iv_target    TYPE string
                iv_left      TYPE string
                iv_right     TYPE string
      RETURNING VALUE(rv_ok) TYPE abap_bool.
ENDCLASS.

CLASS zcl_mcp_metadata IMPLEMENTATION.

  METHOD get_fields.
    DATA lo_type TYPE REF TO cl_abap_typedescr.
    DATA lt_ddic TYPE ddfields.

    DATA(lv_name) = to_upper( condense( iv_name ) ).
    READ TABLE gt_cache INTO DATA(ls_cache) WITH TABLE KEY name = lv_name.
    IF sy-subrc = 0.
      rt_fields = ls_cache-fields.
      RETURN.
    ENDIF.

    cl_abap_typedescr=>describe_by_name(
      EXPORTING  p_name         = lv_name
      RECEIVING  p_descr_ref    = lo_type
      EXCEPTIONS type_not_found = 1
                 OTHERS         = 2 ).
    IF sy-subrc <> 0 OR lo_type->kind <> cl_abap_typedescr=>kind_struct.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |{ lv_name } is not a table, view or CDS entity in the DDIC.|.
    ENDIF.

    CAST cl_abap_structdescr( lo_type )->get_ddic_field_list(
      RECEIVING  p_field_list = lt_ddic
      EXCEPTIONS not_found    = 1
                 no_ddic_type = 2
                 OTHERS       = 3 ).
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |No DDIC field list available for { lv_name }.|.
    ENDIF.

    rt_fields = lt_ddic.
    DELETE rt_fields WHERE datatype = 'CLNT'.     " client is handled by Open SQL
    INSERT VALUE #( name = lv_name fields = rt_fields ) INTO TABLE gt_cache.
  ENDMETHOD.

  METHOD leading_key.
    LOOP AT it_fields INTO rs_field WHERE keyflag = abap_true.
      RETURN.
    ENDLOOP.
    CLEAR rs_field.
  ENDMETHOD.

  METHOD parse_relations.
    DATA lt_targets TYPE string_table.
    DATA lt_pairs   TYPE string_table.
    DATA lv_target  TYPE string.
    DATA lv_rest    TYPE string.
    DATA lv_left    TYPE string.
    DATA lv_right   TYPE string.

    SPLIT iv_text AT ';' INTO TABLE lt_targets.
    LOOP AT lt_targets INTO DATA(lv_part).
      CLEAR: lv_target, lv_rest.
      SPLIT lv_part AT ':' INTO lv_target lv_rest.
      lv_target = to_upper( condense( lv_target ) ).
      IF lv_target IS INITIAL OR lv_rest IS INITIAL.
        CONTINUE.
      ENDIF.
      DATA(ls_rel) = VALUE zif_mcp_types=>ty_relation( target = lv_target origin = `configured` ).
      SPLIT lv_rest AT ',' INTO TABLE lt_pairs.
      LOOP AT lt_pairs INTO DATA(lv_pair).
        CLEAR: lv_left, lv_right.
        SPLIT lv_pair AT '=' INTO lv_left lv_right.
        APPEND VALUE #( left  = to_upper( condense( lv_left ) )
                        right = to_upper( condense( lv_right ) ) ) TO ls_rel-pairs.
      ENDLOOP.
      APPEND ls_rel TO rt_rel.
    ENDLOOP.
  ENDMETHOD.

  METHOD get_relations.
    DATA lt_self  TYPE zif_mcp_types=>tt_dfies.
    DATA lt_other TYPE zif_mcp_types=>tt_dfies.

    rt_rel = parse_relations( is_reg-relations ).
    TRY.
        lt_self = get_fields( is_reg-obj_name ).
      CATCH zcx_mcp_error.
        RETURN.
    ENDTRY.

    LOOP AT it_regs INTO DATA(ls_other)
         WHERE ( obj_type = 'TABLE' OR obj_type = 'CDS' ) AND obj_name <> is_reg-obj_name.
      DATA(lv_target) = CONV string( ls_other-obj_name ).
      IF line_exists( rt_rel[ target = lv_target ] ).
        CONTINUE.                                   " configured relation wins
      ENDIF.
      TRY.
          lt_other = get_fields( ls_other-obj_name ).
        CATCH zcx_mcp_error.
          CONTINUE.
      ENDTRY.

      DATA(ls_lead) = leading_key( lt_other ).
      IF ls_lead IS INITIAL OR is_joinable_type( ls_lead ) = abap_false.
        CONTINUE.
      ENDIF.

      DATA(ls_rel) = VALUE zif_mcp_types=>ty_relation( target = lv_target origin = `derived` ).
      " walk the key of the other object; stop at the first key field we cannot match
      LOOP AT lt_other INTO DATA(ls_key) WHERE keyflag = abap_true.
        IF is_joinable_type( ls_key ) = abap_false.
          EXIT.                                     " e.g. language key of text tables
        ENDIF.
        READ TABLE lt_self INTO DATA(ls_match)
             WITH KEY fieldname = ls_key-fieldname domname = ls_key-domname.
        IF sy-subrc <> 0.
          READ TABLE lt_self INTO ls_match WITH KEY domname = ls_key-domname.
        ENDIF.
        IF sy-subrc <> 0.
          EXIT.
        ENDIF.
        APPEND VALUE #( left = CONV #( ls_match-fieldname ) right = CONV #( ls_key-fieldname ) )
          TO ls_rel-pairs.
      ENDLOOP.

      IF ls_rel-pairs IS NOT INITIAL.
        APPEND ls_rel TO rt_rel.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD is_join_allowed.
    DATA(lv_left_name)   = CONV string( is_left_reg-obj_name ).
    DATA(lv_right_name)  = CONV string( is_right_reg-obj_name ).
    DATA(lv_left_field)  = CONV string( is_left_field-fieldname ).
    DATA(lv_right_field) = CONV string( is_right_field-fieldname ).

    " 1) configured relations, in either direction
    IF has_pair( it_rel    = parse_relations( is_left_reg-relations )
                 iv_target = lv_right_name
                 iv_left   = lv_left_field
                 iv_right  = lv_right_field ) = abap_true
    OR has_pair( it_rel    = parse_relations( is_right_reg-relations )
                 iv_target = lv_left_name
                 iv_left   = lv_right_field
                 iv_right  = lv_left_field ) = abap_true.
      rv_ok = abap_true.
      RETURN.
    ENDIF.

    " 2) derived: same domain, joinable type, at least one side is a key field
    IF is_left_field-domname IS NOT INITIAL
       AND is_left_field-domname = is_right_field-domname
       AND is_joinable_type( is_left_field ) = abap_true
       AND ( is_left_field-keyflag = abap_true OR is_right_field-keyflag = abap_true ).
      rv_ok = abap_true.
    ENDIF.
  ENDMETHOD.

  METHOD has_pair.
    READ TABLE it_rel INTO DATA(ls_rel) WITH KEY target = iv_target.
    IF sy-subrc = 0.
      rv_ok = xsdbool( line_exists( ls_rel-pairs[ left = iv_left right = iv_right ] ) ).
    ENDIF.
  ENDMETHOD.

  METHOD is_joinable_type.
    rv_ok = xsdbool( is_field-domname IS NOT INITIAL
                     AND ( is_field-datatype = 'CHAR' OR is_field-datatype = 'NUMC' ) ).
  ENDMETHOD.

ENDCLASS.
