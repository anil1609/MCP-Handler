# SAP MCP Data Gateway (SICF/REST, ECC and S/4HANA)

Generic, registry-driven, read-only gateway that exposes SAP data to AI agents through
ONE MCP server on SAP Integration Suite (source type: API), with four clear tools:

| MCP tool (operationId) | HTTP | Purpose |
|---|---|---|
| `listObjects` | `POST /list` | Find registered objects + domain rules |
| `describeObject` | `POST /describe` | Fields, keys, mandatory filters, relations, CDS associations, BAPI parameters |
| `queryData` | `POST /query` | Read rows from tables, CDS entities (with joins) or OData entity sets |
| `callFunction` | `POST /call` | Call a registered read-only BAPI/FM |

Supported sources (OBJ_TYPE): **TABLE, CDS, ODATA (V4 and V2), BAPI, FM**.
Adding or removing a data object = one row in `ZMCP_REGISTRY`. No BTP change, no redeploy.

## Architecture

```
Chat client (custom app / any MCP client)
  -> MCP server (Integration Suite, source = API artifact, 4 tools from openapi.yaml)
  -> API proxy (API Management) -> Cloud Connector (HTTPS, principal propagation, X.509)
  -> SICF node /sap/zmcp/gateway -> ZCL_MCP_HTTP_HANDLER
  -> ZCL_MCP_GATEWAY (routing, errors, SLG1 logging)
       -> ZCL_MCP_REGISTRY (ZMCP_REGISTRY allowlist)
       -> ZIF_MCP_SOURCE_HANDLER
            ZCL_MCP_TABLE_HANDLER  TABLE + CDS: dynamic SELECT, joins, CDS association paths
            ZCL_MCP_ODATA_HANDLER  ODATA: V2 via loopback HTTP, V4 delegated to ZCL_MCP_ODATA_V4
            ZCL_MCP_ODATA_V4       V4 local client proxy (S/4 only, created dynamically)
            ZCL_MCP_FUNC_HANDLER   BAPI / FM: dynamic CALL FUNCTION + ROLLBACK WORK
       -> ZCL_MCP_METADATA (DDIC fields, derived relations)   ZCL_MCP_CDS_META (associations)
       -> ZCL_MCP_VALUE (ALPHA/NUMC/date conversion)          ZCL_MCP_ORG_AUTH (row-level auth for tables)
       -> ZCL_MCP_ENVELOPE + ZCL_MCP_JSON (response JSON)
```

## Files

```
ddic/zmcp_registry.md                 table definition, SERVICE_REF format, seed entries (ECC + S/4)
src/zif_mcp_types.intf.abap           shared types and limits
src/zcx_mcp_error.clas.abap           exception (message is returned to the LLM)
src/zcl_mcp_json.clas.abap            tiny JSON writer + object extractor
src/zcl_mcp_registry.clas.abap        registry access
src/zcl_mcp_metadata.clas.abap        DDIC metadata, relations, join validation
src/zcl_mcp_cds_meta.clas.abap        CDS associations (DD08B, dynamic access)
src/zcl_mcp_value.clas.abap           value conversion to internal format
src/zcl_mcp_org_auth.clas.abap        org-level authorization conditions (tables)
src/zcl_mcp_envelope.clas.abap        result envelope (columns/rows/cells)
src/zif_mcp_source_handler.intf.abap  handler contract (extension point)
src/zcl_mcp_table_handler.clas.abap   TABLE/CDS handler
src/zcl_mcp_odata_handler.clas.abap   ODATA handler (common + V2)
src/zcl_mcp_odata_v4.clas.abap        ODATA V4 (S/4 only)
src/zcl_mcp_func_handler.clas.abap    BAPI/FM handler
src/zcl_mcp_gateway.clas.abap         orchestrator
src/zcl_mcp_http_handler.clas.abap    SICF handler (IF_HTTP_EXTENSION)
api/openapi.yaml                      spec for the API proxy / MCP tools
examples/requests.md                  end-to-end request/response examples
```

## Prerequisites

- NetWeaver 7.40 SP08 or higher (inline declarations, VALUE/COND/SWITCH, xsdbool, Open SQL with `@`).
- `/UI2/CL_JSON` (component SAP_UI) for parsing request bodies.
- CDS: S/4HANA (or any system with DDIC-based CDS entities, 7.50+). CDS entities with parameters are not supported.
- OData V4: S/4HANA with the Gateway client proxy (`/IWBEP/CL_CP_CLIENT_PROXY_FACTORY`). Skip `ZCL_MCP_ODATA_V4` elsewhere.
- OData V2: an SM59 type H destination to the same system with current-user logon (SSO / logon ticket).
- No `OFFSET` in Open SQL before 7.51: table/CDS paging is emulated (fetch offset+limit+1, then cut).

## Build order

1. Table `ZMCP_REGISTRY` (see `ddic/zmcp_registry.md`), SM30 maintenance, seed rows.
2. SLG0: log object `ZMCP`, subobject `GATEWAY` (logging silently skips if missing).
3. Create: `ZIF_MCP_TYPES`, `ZCX_MCP_ERROR`, `ZCL_MCP_JSON`, `ZCL_MCP_REGISTRY`, `ZCL_MCP_METADATA`,
   `ZCL_MCP_CDS_META`, `ZCL_MCP_VALUE`, `ZCL_MCP_ORG_AUTH`, `ZCL_MCP_ENVELOPE`, `ZIF_MCP_SOURCE_HANDLER`,
   `ZCL_MCP_TABLE_HANDLER`, `ZCL_MCP_FUNC_HANDLER`, `ZCL_MCP_ODATA_HANDLER`,
   `ZCL_MCP_ODATA_V4` (S/4 only), `ZCL_MCP_GATEWAY`, `ZCL_MCP_HTTP_HANDLER`.
4. SICF: service node `/sap/zmcp/gateway`, handler `ZCL_MCP_HTTP_HANDLER`, logon via client certificate / SSO. Activate.
5. For V2 OData: SM59 destination (e.g. `ZMCP_LOOPBACK`) to the same system, current-user logon.
6. Test with the bodies in `examples/requests.md`. `GET /sap/zmcp/gateway/health` returns `{"status":"OK"}`.

## Verify on your release

These are used by name or dynamically and differ between releases. Check them before activating:

- `VIEW_AUTHORITY_CHECK` (exception `NO_AUTHORITY`), `FUNCTION_IMPORT_INTERFACE` (tables incl. `P_DOCU`),
  `BAL_LOG_CREATE`, `BAL_LOG_MSG_ADD_FREE_TEXT`, `BAL_DB_SAVE` (`I_2TH_CONNECTION`).
- DD08B field names in `ZCL_MCP_CDS_META` (ASSOCIATIONNAME, STRUCOBJN, STRUCOBJN_T, CARDINALITY_MIN/MAX, AS4LOCAL).
  If they differ, associations are silently disabled; fix the select list.
- OData V4 client proxy API in `ZCL_MCP_ODATA_V4`: `create_v4_local_proxy` key fields, `ty_t_property_path`,
  `ty_t_sort_order` (property_path, descending), `set_select_properties`, `set_orderby`, `set_top`, `set_skip`,
  `create_filter_factory( )->create_by_range`, `get_business_data`.
- `CL_HTTP_UTILITY=>ESCAPE_URL`, sXML classes (`CL_SXML_STRING_READER`, `CX_SXML_ERROR`).
- Org-auth rules in `ZCL_MCP_ORG_AUTH=>GET_RULES` (M_BEST_EKO, M_BEST_WRK, F_BKPF_BUK).

## How each source works

**TABLE** - dynamic SELECT with validated fields/filters, joins along derived relations (same domain,
key field) or RELATIONS overrides, S_TABU_DIS/S_TABU_NAM check, org-level WHERE restriction.

**CDS** - same engine on the entity; the entity's DCL does the authorization. Associations whose
target is registered are listed by describeObject and can be selected as `_Association.FIELD`
(select list only; to filter on the target, join it). Prefer released VDM views (C1 contract).

**ODATA V4** - local client proxy: no HTTP hop, runs as the caller, service logic + DCL apply.
Filters become ranges (EQ, NE, GT, GE, LT, LE, BT, IN, CP), plus $select, $orderby, $top, $skip.

**ODATA V2** - GET through the loopback destination: $metadata gives property names, EDM types,
labels and keys; filters become `$filter` with typed literals (datetime'', 100M, guid'', ...);
`/Date(...)/` values are returned as YYYY-MM-DD. Values are passed as sent (no conversion exits).

**BAPI / FM** - interface from FUNCTION_IMPORT_INTERFACE, params from JSON, dynamic call,
ROLLBACK WORK always, RETURN messages of type E/A turn the status into ERROR.

## BTP setup (configuration only)

1. Cloud Connector: HTTPS system mapping, resource `/sap/zmcp/gateway` (path and sub-paths),
   principal propagation (X.509; backend rule-based certificate mapping, e.g. CERTRULE).
2. API Management: API provider (on-premise via Cloud Connector), API proxy from `api/openapi.yaml`, policies, deploy.
3. Integration Suite: MCP server with source = API artifact; tools `listObjects`, `describeObject`,
   `queryData`, `callFunction`. Review descriptions, deploy, publish.

## Security model

- Only `ACTIVE = 'X'` registry objects are reachable; `HIDDEN_FIELDS` are never exposed
  (also for association targets, which must be registered themselves).
- Structured filters only (no SQL/OData text from the LLM); names validated, values converted and escaped.
- Tables: table authorization + org-level row restriction. CDS: DCL. OData: service checks + DCL.
- Functions: registered only, ROLLBACK WORK after every call.
- Row caps (registry MAX_ROWS, hard cap 1000; 500 per function result set). Every call logged in SLG1.

## Known limits

- Max 4 joins, 50 fields, 500 IN values. OData objects cannot be joined.
- Association paths: select list only, one level (`_A.FIELD`, not `_A._B.FIELD`).
- Org-auth on a LEFT-joined table is applied in WHERE (unmatched rows are dropped).
- V2 OData: property mapping relies on $metadata; SEGW services with unusual EDMX may need a RELATIONS-free CDS alternative.
- No aggregates yet (`groupBy`/`SUM`): extend `TY_QUERY_ARGS` and `BUILD_SELECT`.

## Prompt for your VS Code assistant

> Use the files in this folder as the reference implementation. Targets: ECC 6.0 on NW 7.40 SP08 (without
> ZCL_MCP_ODATA_V4) and S/4HANA on-premise (all classes). Keep the class split and method contracts.
> Check every statement against 7.40 syntax, verify the items under "Verify on your release",
> and add ABAP Unit tests for ZCL_MCP_TABLE_HANDLER (build_where, resolve incl. association paths,
> build_from), ZCL_MCP_VALUE and ZCL_MCP_ODATA_HANDLER (v2_filter, v2_literal, parse_v2_results).
