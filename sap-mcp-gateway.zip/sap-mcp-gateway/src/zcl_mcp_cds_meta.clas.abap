"! CDS association metadata, read from the DDIC table DD08B (associations of CDS entities).
"! Access is fully dynamic, so this class also activates on ECC: if DD08B or one of its
"! fields does not exist on your release, it simply returns no associations
"! (joins via derived relations / RELATIONS still work).
CLASS zcl_mcp_cds_meta DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    TYPES: BEGIN OF ty_assoc,
             name        TYPE string,   " e.g. _PURCHASEORDERITEM
             target      TYPE string,   " e.g. I_PURCHASEORDERITEMAPI01
             cardinality TYPE string,   " e.g. 0..*
           END OF ty_assoc,
           tt_assoc TYPE STANDARD TABLE OF ty_assoc WITH EMPTY KEY.
    CLASS-METHODS get_associations
      IMPORTING iv_entity       TYPE csequence
      RETURNING VALUE(rt_assoc) TYPE tt_assoc.
  PRIVATE SECTION.
    TYPES: BEGIN OF ty_cache,
             entity TYPE string,
             assoc  TYPE tt_assoc,
           END OF ty_cache.
    CLASS-DATA gt_cache TYPE HASHED TABLE OF ty_cache WITH UNIQUE KEY entity.
ENDCLASS.

CLASS zcl_mcp_cds_meta IMPLEMENTATION.

  METHOD get_associations.
    TYPES: BEGIN OF ty_row,
             assoc    TYPE c LENGTH 40,
             target   TYPE c LENGTH 40,
             card_min TYPE c LENGTH 10,
             card_max TYPE c LENGTH 10,
           END OF ty_row.
    DATA lt_rows TYPE STANDARD TABLE OF ty_row WITH EMPTY KEY.

    DATA(lv_entity) = to_upper( condense( iv_entity ) ).
    READ TABLE gt_cache INTO DATA(ls_cache) WITH TABLE KEY entity = lv_entity.
    IF sy-subrc = 0.
      rt_assoc = ls_cache-assoc.
      RETURN.
    ENDIF.

    DATA(lv_select) = `ASSOCIATIONNAME AS ASSOC, STRUCOBJN_T AS TARGET, CARDINALITY_MIN AS CARD_MIN, CARDINALITY_MAX AS CARD_MAX`.
    DATA(lv_from)   = `DD08B`.
    DATA(lv_where)  = |STRUCOBJN = { cl_abap_dyn_prg=>quote( lv_entity ) } AND AS4LOCAL = 'A'|.
    TRY.
        SELECT (lv_select) FROM (lv_from)
          INTO CORRESPONDING FIELDS OF TABLE @lt_rows
          WHERE (lv_where).
      CATCH cx_sy_dynamic_osql_error cx_sy_open_sql_db.
        CLEAR lt_rows.                              " not available -> no associations
    ENDTRY.

    LOOP AT lt_rows INTO DATA(ls_row).
      DATA(lv_max) = condense( CONV string( ls_row-card_max ) ).
      APPEND VALUE #( name        = to_upper( condense( CONV string( ls_row-assoc ) ) )
                      target      = to_upper( condense( CONV string( ls_row-target ) ) )
                      cardinality = |{ condense( CONV string( ls_row-card_min ) ) }..| &&
                                    COND string( WHEN lv_max = `0` OR lv_max = `` OR lv_max = `-1` THEN `*` ELSE lv_max ) )
        TO rt_assoc.
    ENDLOOP.

    INSERT VALUE #( entity = lv_entity assoc = rt_assoc ) INTO TABLE gt_cache.
  ENDMETHOD.

ENDCLASS.
