"! Access to the allowlist table ZMCP_REGISTRY.
CLASS zcl_mcp_registry DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    "! Active, non-DOMAIN entry or exception with guidance for the LLM
    CLASS-METHODS get
      IMPORTING iv_obj_name   TYPE csequence
      RETURNING VALUE(rs_reg) TYPE zmcp_registry
      RAISING   zcx_mcp_error.
    CLASS-METHODS get_all_active
      RETURNING VALUE(rt_reg) TYPE zif_mcp_types=>tt_registry.
    "! 'A, b ,C' -> ( 'A' 'B' 'C' )
    CLASS-METHODS split_list
      IMPORTING iv_list         TYPE csequence
      RETURNING VALUE(rt_items) TYPE string_table.
ENDCLASS.

CLASS zcl_mcp_registry IMPLEMENTATION.

  METHOD get.
    DATA lv_name TYPE zmcp_registry-obj_name.
    lv_name = to_upper( condense( iv_obj_name ) ).
    IF lv_name IS INITIAL.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = `objName is required. Call listObjects to see available objects.`.
    ENDIF.

    SELECT SINGLE * FROM zmcp_registry INTO @rs_reg WHERE obj_name = @lv_name.
    IF sy-subrc <> 0 OR rs_reg-active <> abap_true OR rs_reg-obj_type = 'DOMAIN'.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Object { lv_name } is not registered or not active. | &&
                            |Call listObjects to see available objects.|.
    ENDIF.
  ENDMETHOD.

  METHOD get_all_active.
    SELECT * FROM zmcp_registry INTO TABLE @rt_reg
      WHERE active = @abap_true
      ORDER BY obj_name.
  ENDMETHOD.

  METHOD split_list.
    DATA lt_raw TYPE string_table.
    SPLIT iv_list AT ',' INTO TABLE lt_raw.
    LOOP AT lt_raw INTO DATA(lv_item).
      lv_item = to_upper( condense( lv_item ) ).
      IF lv_item IS NOT INITIAL.
        APPEND lv_item TO rt_items.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

ENDCLASS.
