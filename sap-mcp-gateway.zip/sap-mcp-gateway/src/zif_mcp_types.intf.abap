INTERFACE zif_mcp_types PUBLIC.

  CONSTANTS:
    c_default_max_rows TYPE i VALUE 100,
    c_hard_max_rows    TYPE i VALUE 1000,
    c_max_offset       TYPE i VALUE 5000,
    c_default_fields   TYPE i VALUE 20,
    c_max_fields       TYPE i VALUE 50,
    c_max_joins        TYPE i VALUE 4,
    c_max_in_values    TYPE i VALUE 500.

  TYPES tt_registry TYPE STANDARD TABLE OF zmcp_registry WITH EMPTY KEY.
  TYPES tt_dfies    TYPE STANDARD TABLE OF dfies WITH EMPTY KEY.

  " ---- request structures (parsed from JSON, camelCase -> UNDER_SCORE)
  TYPES: BEGIN OF ty_filter,
           field  TYPE string,
           op     TYPE string,
           value  TYPE string,
           low    TYPE string,
           high   TYPE string,
           values TYPE string_table,
         END OF ty_filter,
         tt_filter TYPE STANDARD TABLE OF ty_filter WITH EMPTY KEY.

  TYPES: BEGIN OF ty_join_key,
           left  TYPE string,
           right TYPE string,
         END OF ty_join_key,
         tt_join_key TYPE STANDARD TABLE OF ty_join_key WITH EMPTY KEY.

  TYPES: BEGIN OF ty_join,
           obj_name TYPE string,
           type     TYPE string,
           keys     TYPE tt_join_key,
         END OF ty_join,
         tt_join TYPE STANDARD TABLE OF ty_join WITH EMPTY KEY.

  TYPES: BEGIN OF ty_list_args,
           domain TYPE string,
           search TYPE string,
         END OF ty_list_args.

  TYPES: BEGIN OF ty_describe_args,
           obj_name TYPE string,
         END OF ty_describe_args.

  TYPES: BEGIN OF ty_query_args,
           obj_name TYPE string,
           fields   TYPE string_table,
           filters  TYPE tt_filter,
           joins    TYPE tt_join,
           order_by TYPE string,
           max_rows TYPE i,
           offset   TYPE i,
         END OF ty_query_args.

  TYPES: BEGIN OF ty_call_args,
           obj_name TYPE string,
         END OF ty_call_args.

  " ---- result column metadata
  TYPES: BEGIN OF ty_col,
           comp     TYPE string,   " component name in the result table (C001...)
           name     TYPE string,   " name shown to the LLM
           label    TYPE string,
           inttype  TYPE inttype,
           datatype TYPE string,
           convexit TYPE convexit,
           typename TYPE string,   " DDIC type used to build the result table, e.g. EKKO-EBELN
         END OF ty_col,
         tt_col TYPE STANDARD TABLE OF ty_col WITH EMPTY KEY.

  " ---- relations between registry objects
  TYPES: BEGIN OF ty_pair,
           left  TYPE string,
           right TYPE string,
         END OF ty_pair,
         tt_pair TYPE STANDARD TABLE OF ty_pair WITH EMPTY KEY.

  TYPES: BEGIN OF ty_relation,
           target TYPE string,
           origin TYPE string,     " derived | configured
           pairs  TYPE tt_pair,
         END OF ty_relation,
         tt_relation TYPE STANDARD TABLE OF ty_relation WITH EMPTY KEY.

ENDINTERFACE.
