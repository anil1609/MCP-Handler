"! Handler for TABLE and CDS objects.
"! Turns the structured query JSON into a validated dynamic Open SQL SELECT:
"!   fields  -> select list (aliased C001..), filters -> WHERE, joins -> FROM, orderBy -> ORDER BY.
"! The LLM never sends SQL text.
"! TABLE: S_TABU_DIS/S_TABU_NAM check + org-level row restriction (ZCL_MCP_ORG_AUTH).
"! CDS:   protected by the entity's DCL; association paths allowed in fields
"!        (_Assoc.Field or OBJECT._Assoc.Field) when the target entity is registered.
CLASS zcl_mcp_table_handler DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES zif_mcp_source_handler.
  PRIVATE SECTION.
    TYPES: BEGIN OF ty_source,
             alias  TYPE string,
             reg    TYPE zmcp_registry,
             fields TYPE zif_mcp_types=>tt_dfies,
             hidden TYPE string_table,
           END OF ty_source,
           tt_source TYPE STANDARD TABLE OF ty_source WITH EMPTY KEY.
    TYPES: BEGIN OF ty_resolved,
             alias    TYPE string,
             object   TYPE string,     " object that owns the field (association target for paths)
             field    TYPE dfies,
             sql      TYPE string,     " t0~FIELD or t0~\_ASSOC-FIELD
             typename TYPE string,     " OBJECT-FIELD, used for typing and conversion
             display  TYPE string,     " name shown to the LLM
             is_path  TYPE abap_bool,
           END OF ty_resolved.

    DATA mt_sources   TYPE tt_source.        " t0 = main object, t1.. = joined objects
    DATA mv_qualified TYPE abap_bool.        " show OBJECT.FIELD names when joins are used

    METHODS add_source
      IMPORTING is_reg TYPE zmcp_registry
      RAISING   zcx_mcp_error.
    METHODS resolve
      IMPORTING iv_ref        TYPE string
      RETURNING VALUE(rs_res) TYPE ty_resolved
      RAISING   zcx_mcp_error.
    METHODS resolve_column
      IMPORTING iv_ref        TYPE string
      RETURNING VALUE(rs_res) TYPE ty_resolved
      RAISING   zcx_mcp_error.
    METHODS build_from
      IMPORTING it_joins       TYPE zif_mcp_types=>tt_join
      RETURNING VALUE(rv_from) TYPE string
      RAISING   zcx_mcp_error.
    METHODS build_select
      IMPORTING it_fields TYPE string_table
      EXPORTING ev_select TYPE string
                et_cols   TYPE zif_mcp_types=>tt_col
                ev_hint   TYPE string
      RAISING   zcx_mcp_error.
    METHODS build_where
      IMPORTING it_filters      TYPE zif_mcp_types=>tt_filter
      RETURNING VALUE(rv_where) TYPE string
      RAISING   zcx_mcp_error.
    METHODS build_order
      IMPORTING iv_order_by     TYPE string
      RETURNING VALUE(rv_order) TYPE string
      RAISING   zcx_mcp_error.
    METHODS to_literal
      IMPORTING is_res            TYPE ty_resolved
                iv_value          TYPE string
      RETURNING VALUE(rv_literal) TYPE string
      RAISING   zcx_mcp_error.
    METHODS check_mandatory
      IMPORTING it_filters TYPE zif_mcp_types=>tt_filter
      RAISING   zcx_mcp_error.
    METHODS check_authorization
      RETURNING VALUE(rv_where) TYPE string
      RAISING   zcx_mcp_error.
    METHODS create_result_table
      IMPORTING it_cols         TYPE zif_mcp_types=>tt_col
      RETURNING VALUE(rr_table) TYPE REF TO data
      RAISING   zcx_mcp_error.
    METHODS effective_max_rows
      IMPORTING is_reg         TYPE zmcp_registry
      RETURNING VALUE(rv_rows) TYPE i.
ENDCLASS.

CLASS zcl_mcp_table_handler IMPLEMENTATION.

  " ===================================================================== DESCRIBE
  METHOD zif_mcp_source_handler~describe.
    DATA lt_field_json TYPE string_table.
    DATA lt_rel_json   TYPE string_table.
    DATA lt_assoc_json TYPE string_table.
    DATA lt_pairs      TYPE string_table.
    DATA lt_keys       TYPE string_table.
    DATA lt_out        TYPE string_table.

    DATA(lt_fields) = zcl_mcp_metadata=>get_fields( is_reg-obj_name ).
    DATA(lt_hidden) = zcl_mcp_registry=>split_list( is_reg-hidden_fields ).
    DATA(lt_regs)   = zcl_mcp_registry=>get_all_active( ).

    LOOP AT lt_fields INTO DATA(ls_f).
      IF line_exists( lt_hidden[ table_line = CONV string( ls_f-fieldname ) ] ).
        CONTINUE.
      ENDIF.
      CLEAR lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `name`   iv_raw = zcl_mcp_json=>str( ls_f-fieldname ) ) TO lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `label`  iv_raw = zcl_mcp_json=>str(
        COND string( WHEN ls_f-scrtext_m IS NOT INITIAL THEN ls_f-scrtext_m ELSE ls_f-fieldtext ) ) ) TO lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `type`   iv_raw = zcl_mcp_json=>str( ls_f-datatype ) ) TO lt_pairs.
      APPEND zcl_mcp_json=>pair( iv_key = `length` iv_raw = zcl_mcp_json=>num( CONV i( ls_f-leng ) ) ) TO lt_pairs.
      IF ls_f-keyflag = abap_true.
        APPEND zcl_mcp_json=>pair( iv_key = `key` iv_raw = `true` ) TO lt_pairs.
      ENDIF.
      IF ls_f-convexit IS NOT INITIAL.
        APPEND zcl_mcp_json=>pair( iv_key = `conversion` iv_raw = zcl_mcp_json=>str( ls_f-convexit ) ) TO lt_pairs.
      ENDIF.
      IF ls_f-reffield IS NOT INITIAL AND ( ls_f-datatype = 'CURR' OR ls_f-datatype = 'QUAN' ).
        APPEND zcl_mcp_json=>pair( iv_key = `unitRef` iv_raw = zcl_mcp_json=>str( ls_f-reffield ) ) TO lt_pairs.
      ENDIF.
      APPEND zcl_mcp_json=>object( lt_pairs ) TO lt_field_json.
    ENDLOOP.

    " relations in the same shape as a join, ready to copy into queryData.joins
    DATA(lt_rel) = zcl_mcp_metadata=>get_relations( is_reg = is_reg it_regs = lt_regs ).
    LOOP AT lt_rel INTO DATA(ls_rel).
      CLEAR lt_keys.
      LOOP AT ls_rel-pairs INTO DATA(ls_pair).
        APPEND zcl_mcp_json=>object( VALUE #(
          ( zcl_mcp_json=>pair( iv_key = `left`  iv_raw = zcl_mcp_json=>str( |{ is_reg-obj_name }.{ ls_pair-left }| ) ) )
          ( zcl_mcp_json=>pair( iv_key = `right` iv_raw = zcl_mcp_json=>str( ls_pair-right ) ) ) ) ) TO lt_keys.
      ENDLOOP.
      APPEND zcl_mcp_json=>object( VALUE #(
        ( zcl_mcp_json=>pair( iv_key = `objName` iv_raw = zcl_mcp_json=>str( ls_rel-target ) ) )
        ( zcl_mcp_json=>pair( iv_key = `keys`    iv_raw = zcl_mcp_json=>array( lt_keys ) ) )
        ( zcl_mcp_json=>pair( iv_key = `origin`  iv_raw = zcl_mcp_json=>str( ls_rel-origin ) ) ) ) ) TO lt_rel_json.
    ENDLOOP.

    " CDS associations whose target is registered and active
    IF is_reg-obj_type = 'CDS'.
      DATA(lt_assoc) = zcl_mcp_cds_meta=>get_associations( is_reg-obj_name ).
      LOOP AT lt_assoc INTO DATA(ls_assoc).
        IF NOT line_exists( lt_regs[ obj_name = ls_assoc-target ] ).
          CONTINUE.
        ENDIF.
        APPEND zcl_mcp_json=>object( VALUE #(
          ( zcl_mcp_json=>pair( iv_key = `name`        iv_raw = zcl_mcp_json=>str( ls_assoc-name ) ) )
          ( zcl_mcp_json=>pair( iv_key = `target`      iv_raw = zcl_mcp_json=>str( ls_assoc-target ) ) )
          ( zcl_mcp_json=>pair( iv_key = `cardinality` iv_raw = zcl_mcp_json=>str( ls_assoc-cardinality ) ) ) ) )
          TO lt_assoc_json.
      ENDLOOP.
    ENDIF.

    " domain rules, if a DOMAIN row exists for this object's domain
    DATA(lv_rules) = VALUE string( ).
    READ TABLE lt_regs INTO DATA(ls_domain) WITH KEY obj_type = 'DOMAIN' obj_name = is_reg-domain.
    IF sy-subrc = 0.
      lv_rules = ls_domain-description.
    ENDIF.

    DATA(lv_hint) = `Use queryData. When joining, qualify fields as OBJECT.FIELD and copy a relation into joins. ` &&
                    `Language keys of text tables are added automatically. Dates as YYYY-MM-DD.`.
    IF is_reg-obj_type = 'CDS'.
      lv_hint = lv_hint && ` Association fields can be selected as _Association.Field (fields only, not filters).`.
    ENDIF.

    APPEND zcl_mcp_json=>pair( iv_key = `status`       iv_raw = zcl_mcp_json=>str( `OK` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `action`       iv_raw = zcl_mcp_json=>str( `DESCRIBE` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `object`       iv_raw = zcl_mcp_json=>str( is_reg-obj_name ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `type`         iv_raw = zcl_mcp_json=>str( is_reg-obj_type ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `domain`       iv_raw = zcl_mcp_json=>str( is_reg-domain ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `description`  iv_raw = zcl_mcp_json=>str( is_reg-description ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `domainRules`  iv_raw = zcl_mcp_json=>str( lv_rules ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `maxRows`      iv_raw = zcl_mcp_json=>num( effective_max_rows( is_reg ) ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `mandatoryFilters`
                               iv_raw = zcl_mcp_json=>str_array( zcl_mcp_registry=>split_list( is_reg-mandatory_filters ) ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `fields`       iv_raw = zcl_mcp_json=>array( lt_field_json ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `relations`    iv_raw = zcl_mcp_json=>array( lt_rel_json ) ) TO lt_out.
    IF is_reg-obj_type = 'CDS'.
      APPEND zcl_mcp_json=>pair( iv_key = `associations` iv_raw = zcl_mcp_json=>array( lt_assoc_json ) ) TO lt_out.
    ENDIF.
    APPEND zcl_mcp_json=>pair( iv_key = `hint`         iv_raw = zcl_mcp_json=>str( lv_hint ) ) TO lt_out.
    rv_json = zcl_mcp_json=>object( lt_out ).
  ENDMETHOD.

  " ===================================================================== QUERY
  METHOD zif_mcp_source_handler~query.
    DATA lv_select TYPE string.
    DATA lt_cols   TYPE zif_mcp_types=>tt_col.
    DATA lv_hint   TYPE string.
    DATA lt_out    TYPE string_table.
    FIELD-SYMBOLS <lt_data> TYPE STANDARD TABLE.

    CLEAR mt_sources.
    add_source( is_reg ).
    IF lines( is_args-joins ) > zif_mcp_types=>c_max_joins.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |At most { zif_mcp_types=>c_max_joins } joins are allowed.|.
    ENDIF.
    mv_qualified = xsdbool( is_args-joins IS NOT INITIAL ).

    DATA(lv_from) = build_from( is_args-joins ).
    check_mandatory( is_args-filters ).
    build_select( EXPORTING it_fields = is_args-fields
                  IMPORTING ev_select = lv_select et_cols = lt_cols ev_hint = lv_hint ).
    DATA(lv_where) = build_where( is_args-filters ).
    DATA(lv_auth)  = check_authorization( ).
    IF lv_auth IS NOT INITIAL.
      lv_where = COND #( WHEN lv_where IS INITIAL THEN lv_auth ELSE |( { lv_where } ) AND { lv_auth }| ).
    ENDIF.
    DATA(lv_order) = build_order( is_args-order_by ).

    " limits; Open SQL OFFSET needs 7.51, so fetch offset + limit + 1 and cut
    DATA(lv_limit) = effective_max_rows( is_reg ).
    IF is_args-max_rows > 0.
      lv_limit = nmin( val1 = is_args-max_rows val2 = lv_limit ).
    ENDIF.
    DATA(lv_offset) = nmax( val1 = 0 val2 = nmin( val1 = is_args-offset val2 = zif_mcp_types=>c_max_offset ) ).
    DATA(lv_fetch)  = lv_offset + lv_limit + 1.

    DATA(lr_data) = create_result_table( lt_cols ).
    ASSIGN lr_data->* TO <lt_data>.

    TRY.
        SELECT (lv_select)
          FROM (lv_from)
          INTO CORRESPONDING FIELDS OF TABLE @<lt_data>
          UP TO @lv_fetch ROWS
          WHERE (lv_where)
          ORDER BY (lv_order).
      CATCH cx_sy_dynamic_osql_error cx_sy_open_sql_db INTO DATA(lx_sql).
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text  = |Query failed: { lx_sql->get_text( ) }|
                    previous = lx_sql.
    ENDTRY.

    IF lv_offset > 0.
      IF lines( <lt_data> ) <= lv_offset.
        CLEAR <lt_data>.
      ELSE.
        DELETE <lt_data> FROM 1 TO lv_offset.
      ENDIF.
    ENDIF.
    DATA(lv_truncated) = xsdbool( lines( <lt_data> ) > lv_limit ).
    IF lv_truncated = abap_true.
      DATA(lv_cut_from) = lv_limit + 1.
      DELETE <lt_data> FROM lv_cut_from.
    ENDIF.

    APPEND zcl_mcp_json=>pair( iv_key = `status`    iv_raw = zcl_mcp_json=>str( `OK` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `action`    iv_raw = zcl_mcp_json=>str( `QUERY` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `source`    iv_raw = zcl_mcp_json=>str( is_reg-obj_name ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `columns`   iv_raw = zcl_mcp_envelope=>columns( lt_cols ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `rows`      iv_raw = zcl_mcp_envelope=>rows( it_data = <lt_data> it_cols = lt_cols ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `rowCount`  iv_raw = zcl_mcp_json=>num( lines( <lt_data> ) ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `truncated` iv_raw = zcl_mcp_json=>bool( lv_truncated ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `nextOffset`
                               iv_raw = COND string( WHEN lv_truncated = abap_true
                                                     THEN zcl_mcp_json=>num( lv_offset + lv_limit )
                                                     ELSE `null` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `message`   iv_raw = zcl_mcp_json=>str( lv_hint ) ) TO lt_out.
    rv_json = zcl_mcp_json=>object( lt_out ).
  ENDMETHOD.

  METHOD zif_mcp_source_handler~execute.
    RAISE EXCEPTION TYPE zcx_mcp_error
      EXPORTING iv_text = |{ is_reg-obj_name } is a { is_reg-obj_type } object. Use queryData instead of callFunction.|.
  ENDMETHOD.

  " ===================================================================== building blocks
  METHOD add_source.
    IF line_exists( mt_sources[ reg-obj_name = is_reg-obj_name ] ).
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |{ is_reg-obj_name } is already part of the query.|.
    ENDIF.
    APPEND VALUE #( alias  = |t{ lines( mt_sources ) }|
                    reg    = is_reg
                    fields = zcl_mcp_metadata=>get_fields( is_reg-obj_name )
                    hidden = zcl_mcp_registry=>split_list( is_reg-hidden_fields ) ) TO mt_sources.
  ENDMETHOD.

  METHOD resolve.
    " Accepted references: FIELD | OBJECT.FIELD | _ASSOC.FIELD | OBJECT._ASSOC.FIELD
    DATA lt_parts TYPE string_table.
    DATA lv_obj   TYPE string.
    DATA lv_assoc TYPE string.
    DATA lv_fld   TYPE string.

    DATA(lv_ref)  = to_upper( condense( iv_ref ) ).
    DATA(lv_main) = CONV string( mt_sources[ 1 ]-reg-obj_name ).
    SPLIT lv_ref AT '.' INTO TABLE lt_parts.

    CASE lines( lt_parts ).
      WHEN 1.
        lv_obj = lv_main.
        lv_fld = lt_parts[ 1 ].
      WHEN 2.
        IF lt_parts[ 1 ] CP '_*'.
          lv_obj   = lv_main.
          lv_assoc = lt_parts[ 1 ].
        ELSE.
          lv_obj = lt_parts[ 1 ].
        ENDIF.
        lv_fld = lt_parts[ 2 ].
      WHEN 3.
        lv_obj   = lt_parts[ 1 ].
        lv_assoc = lt_parts[ 2 ].
        lv_fld   = lt_parts[ 3 ].
        IF NOT lv_assoc CP '_*'.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Invalid field reference '{ iv_ref }'. Use FIELD, OBJECT.FIELD or _Association.FIELD.|.
        ENDIF.
      WHEN OTHERS.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |Invalid field reference '{ iv_ref }'. Use FIELD, OBJECT.FIELD or _Association.FIELD.|.
    ENDCASE.

    READ TABLE mt_sources INTO DATA(ls_src) WITH KEY reg-obj_name = lv_obj.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Unknown object '{ lv_obj }' in field '{ iv_ref }'. Add it to joins first.|.
    ENDIF.
    rs_res-alias = ls_src-alias.

    IF lv_assoc IS INITIAL.
      " ---- plain field of a source
      READ TABLE ls_src-fields INTO rs_res-field WITH KEY fieldname = lv_fld.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |Field '{ lv_fld }' does not exist in { lv_obj }. | &&
                              |Call describeObject for { lv_obj } to see valid fields.|.
      ENDIF.
      IF line_exists( ls_src-hidden[ table_line = lv_fld ] ).
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |Field '{ lv_fld }' of { lv_obj } is not exposed.|.
      ENDIF.
      rs_res-object   = lv_obj.
      rs_res-sql      = |{ ls_src-alias }~{ lv_fld }|.
      rs_res-typename = |{ lv_obj }-{ lv_fld }|.
      rs_res-display  = COND #( WHEN mv_qualified = abap_true THEN |{ lv_obj }.{ lv_fld }| ELSE lv_fld ).
      RETURN.
    ENDIF.

    " ---- CDS association path
    IF ls_src-reg-obj_type <> 'CDS'.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Association paths are only available on CDS entities ({ lv_obj } is a { ls_src-reg-obj_type }).|.
    ENDIF.
    DATA(lt_assoc) = zcl_mcp_cds_meta=>get_associations( lv_obj ).
    READ TABLE lt_assoc INTO DATA(ls_assoc) WITH KEY name = lv_assoc.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Association { lv_assoc } not found on { lv_obj }. Call describeObject to see associations.|.
    ENDIF.
    DATA(ls_target) = zcl_mcp_registry=>get( ls_assoc-target ).     " target must be registered and active
    DATA(lt_tfields) = zcl_mcp_metadata=>get_fields( ls_target-obj_name ).
    READ TABLE lt_tfields INTO rs_res-field WITH KEY fieldname = lv_fld.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Field '{ lv_fld }' does not exist in association target { ls_assoc-target }.|.
    ENDIF.
    DATA(lt_thidden) = zcl_mcp_registry=>split_list( ls_target-hidden_fields ).
    IF line_exists( lt_thidden[ table_line = lv_fld ] ).
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Field '{ lv_fld }' of { ls_assoc-target } is not exposed.|.
    ENDIF.
    rs_res-object   = ls_assoc-target.
    rs_res-is_path  = abap_true.
    rs_res-sql      = |{ ls_src-alias }~\\{ lv_assoc }-{ lv_fld }|.
    rs_res-typename = |{ ls_assoc-target }-{ lv_fld }|.
    rs_res-display  = COND #( WHEN mv_qualified = abap_true THEN |{ lv_obj }.{ lv_assoc }.{ lv_fld }|
                              ELSE |{ lv_assoc }.{ lv_fld }| ).
  ENDMETHOD.

  METHOD resolve_column.
    " plain columns only (WHERE, ORDER BY, JOIN ON): association paths are select-list only
    rs_res = resolve( iv_ref ).
    IF rs_res-is_path = abap_true.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |'{ iv_ref }' is an association path. Paths can only be used in fields; | &&
                            |to filter or sort on { rs_res-object }, join it instead.|.
    ENDIF.
  ENDMETHOD.

  METHOD build_from.
    DATA lt_on      TYPE string_table.
    DATA lv_join_kw TYPE string.

    DATA(ls_main) = mt_sources[ 1 ].
    rv_from = |{ ls_main-reg-obj_name } AS { ls_main-alias }|.

    LOOP AT it_joins INTO DATA(ls_join).
      DATA(ls_reg) = zcl_mcp_registry=>get( ls_join-obj_name ).
      IF ls_reg-obj_type <> 'TABLE' AND ls_reg-obj_type <> 'CDS'.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |{ ls_reg-obj_name } cannot be joined; only TABLE and CDS objects can.|.
      ENDIF.
      IF ls_join-keys IS INITIAL.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |Join to { ls_reg-obj_name } needs keys. Use the relations from describeObject.|.
      ENDIF.

      add_source( ls_reg ).
      DATA(ls_right_src) = mt_sources[ lines( mt_sources ) ].
      CLEAR lt_on.

      LOOP AT ls_join-keys INTO DATA(ls_key).
        DATA(ls_left) = resolve_column( ls_key-left ).
        IF ls_left-alias = ls_right_src-alias.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Join key '{ ls_key-left }' (left) must refer to an object joined earlier.|.
        ENDIF.
        DATA(lv_right_ref) = COND string( WHEN find( val = ls_key-right sub = `.` ) >= 0 THEN ls_key-right
                                          ELSE |{ ls_reg-obj_name }.{ ls_key-right }| ).
        DATA(ls_right) = resolve_column( lv_right_ref ).
        IF ls_right-alias <> ls_right_src-alias.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Join key '{ ls_key-right }' (right) must be a field of { ls_reg-obj_name }.|.
        ENDIF.

        DATA(ls_left_src) = mt_sources[ alias = ls_left-alias ].
        IF zcl_mcp_metadata=>is_join_allowed( is_left_reg    = ls_left_src-reg
                                              is_left_field  = ls_left-field
                                              is_right_reg   = ls_reg
                                              is_right_field = ls_right-field ) = abap_false.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Join { ls_left-object }.{ ls_left-field-fieldname } = | &&
                                |{ ls_reg-obj_name }.{ ls_right-field-fieldname } is not an allowed relation. | &&
                                |Use the relations listed by describeObject.|.
        ENDIF.
        APPEND |{ ls_right-sql } = { ls_left-sql }| TO lt_on.
      ENDLOOP.

      " text tables (e.g. MAKT): restrict the language key to the logon language
      LOOP AT ls_right_src-fields INTO DATA(ls_lang) WHERE keyflag = abap_true AND datatype = 'LANG'.
        DATA(lv_lang_sql) = |{ ls_right_src-alias }~{ ls_lang-fieldname }|.
        IF find( val = concat_lines_of( table = lt_on sep = ` ` ) sub = lv_lang_sql ) < 0.
          APPEND |{ lv_lang_sql } = { cl_abap_dyn_prg=>quote( CONV string( sy-langu ) ) }| TO lt_on.
        ENDIF.
      ENDLOOP.

      DATA(lv_type) = to_upper( condense( ls_join-type ) ).
      CASE lv_type.
        WHEN `` OR `INNER`.
          lv_join_kw = `INNER JOIN`.
        WHEN `LEFT`.
          lv_join_kw = `LEFT OUTER JOIN`.
        WHEN OTHERS.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Join type '{ ls_join-type }' not supported. Use INNER or LEFT.|.
      ENDCASE.

      rv_from = |{ rv_from } { lv_join_kw } { ls_reg-obj_name } AS { ls_right_src-alias } | &&
                |ON { concat_lines_of( table = lt_on sep = ` AND ` ) }|.
    ENDLOOP.
  ENDMETHOD.

  METHOD build_select.
    DATA lt_refs  TYPE string_table.
    DATA lt_parts TYPE string_table.
    DATA lv_idx   TYPE i.

    CLEAR: ev_select, et_cols, ev_hint.
    lt_refs = it_fields.

    IF lt_refs IS INITIAL.
      DATA(ls_main) = mt_sources[ 1 ].
      LOOP AT ls_main-fields INTO DATA(ls_f).
        IF line_exists( ls_main-hidden[ table_line = CONV string( ls_f-fieldname ) ] ).
          CONTINUE.
        ENDIF.
        APPEND |{ ls_main-reg-obj_name }.{ ls_f-fieldname }| TO lt_refs.
        IF lines( lt_refs ) >= zif_mcp_types=>c_default_fields.
          EXIT.
        ENDIF.
      ENDLOOP.
      ev_hint = |No fields requested; returned the first { lines( lt_refs ) } fields of | &&
                |{ ls_main-reg-obj_name }. Request specific fields for better results.|.
    ENDIF.

    IF lines( lt_refs ) > zif_mcp_types=>c_max_fields.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |At most { zif_mcp_types=>c_max_fields } fields per query.|.
    ENDIF.

    LOOP AT lt_refs INTO DATA(lv_ref).
      DATA(ls_res) = resolve( lv_ref ).               " association paths allowed here
      lv_idx = lv_idx + 1.
      DATA(lv_comp) = |C{ lv_idx WIDTH = 3 ALIGN = RIGHT PAD = '0' }|.
      APPEND |{ ls_res-sql } AS { lv_comp }| TO lt_parts.
      APPEND VALUE #( comp     = lv_comp
                      name     = ls_res-display
                      label    = COND string( WHEN ls_res-field-scrtext_m IS NOT INITIAL
                                              THEN ls_res-field-scrtext_m ELSE ls_res-field-fieldtext )
                      inttype  = ls_res-field-inttype
                      datatype = ls_res-field-datatype
                      convexit = ls_res-field-convexit
                      typename = ls_res-typename ) TO et_cols.
    ENDLOOP.

    ev_select = concat_lines_of( table = lt_parts sep = `, ` ).
  ENDMETHOD.

  METHOD build_where.
    DATA lt_conds TYPE string_table.
    DATA lt_lits  TYPE string_table.
    DATA lv_cond  TYPE string.

    LOOP AT it_filters INTO DATA(ls_filter).
      DATA(ls_res) = resolve_column( ls_filter-field ).
      DATA(lv_op)  = to_upper( condense( ls_filter-op ) ).
      IF lv_op IS INITIAL.
        lv_op = `EQ`.
      ENDIF.

      CASE lv_op.
        WHEN `EQ` OR `NE` OR `GT` OR `GE` OR `LT` OR `LE`.
          DATA(lv_sql_op) = SWITCH string( lv_op WHEN `EQ` THEN `=`  WHEN `NE` THEN `<>`
                                                 WHEN `GT` THEN `>`  WHEN `GE` THEN `>=`
                                                 WHEN `LT` THEN `<`  WHEN `LE` THEN `<=` ).
          lv_cond = |{ ls_res-sql } { lv_sql_op } { to_literal( is_res = ls_res iv_value = ls_filter-value ) }|.

        WHEN `BT`.
          lv_cond = |{ ls_res-sql } BETWEEN { to_literal( is_res = ls_res iv_value = ls_filter-low ) } | &&
                    |AND { to_literal( is_res = ls_res iv_value = ls_filter-high ) }|.

        WHEN `IN`.
          IF ls_filter-values IS INITIAL.
            RAISE EXCEPTION TYPE zcx_mcp_error
              EXPORTING iv_text = |Operator IN needs a non-empty 'values' array (field { ls_filter-field }).|.
          ENDIF.
          IF lines( ls_filter-values ) > zif_mcp_types=>c_max_in_values.
            RAISE EXCEPTION TYPE zcx_mcp_error
              EXPORTING iv_text = |At most { zif_mcp_types=>c_max_in_values } values per IN filter.|.
          ENDIF.
          CLEAR lt_lits.
          LOOP AT ls_filter-values INTO DATA(lv_val).
            APPEND to_literal( is_res = ls_res iv_value = lv_val ) TO lt_lits.
          ENDLOOP.
          lv_cond = |{ ls_res-sql } IN ( { concat_lines_of( table = lt_lits sep = `, ` ) } )|.

        WHEN `CP`.
          IF ls_res-field-inttype <> 'C' AND ls_res-field-inttype <> 'N'.
            RAISE EXCEPTION TYPE zcx_mcp_error
              EXPORTING iv_text = |Operator CP only works on text fields ({ ls_filter-field }).|.
          ENDIF.
          DATA(lv_pattern) = ls_filter-value.
          IF ls_res-field-lowercase IS INITIAL.
            lv_pattern = to_upper( lv_pattern ).
          ENDIF.
          REPLACE ALL OCCURRENCES OF `*` IN lv_pattern WITH `%`.
          lv_cond = |{ ls_res-sql } LIKE { cl_abap_dyn_prg=>quote( lv_pattern ) }|.

        WHEN OTHERS.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Unsupported operator '{ lv_op }'. Use EQ, NE, GT, GE, LT, LE, BT, IN or CP.|.
      ENDCASE.

      APPEND lv_cond TO lt_conds.
    ENDLOOP.

    rv_where = concat_lines_of( table = lt_conds sep = ` AND ` ).
  ENDMETHOD.

  METHOD build_order.
    DATA lt_parts TYPE string_table.
    DATA lt_items TYPE string_table.
    DATA lv_ref   TYPE string.
    DATA lv_dir   TYPE string.

    IF iv_order_by IS NOT INITIAL.
      SPLIT iv_order_by AT ',' INTO TABLE lt_items.
      LOOP AT lt_items INTO DATA(lv_item).
        CLEAR: lv_ref, lv_dir.
        lv_item = condense( lv_item ).
        SPLIT lv_item AT space INTO lv_ref lv_dir.
        DATA(ls_res) = resolve_column( lv_ref ).
        lv_dir = to_upper( lv_dir ).
        APPEND |{ ls_res-sql } { COND string( WHEN lv_dir = `DESC` OR lv_dir = `DESCENDING`
                                             THEN `DESCENDING` ELSE `ASCENDING` ) }| TO lt_parts.
      ENDLOOP.
    ENDIF.

    " always finish with the key of the main object -> stable paging
    DATA(ls_main) = mt_sources[ 1 ].
    LOOP AT ls_main-fields INTO DATA(ls_key) WHERE keyflag = abap_true.
      DATA(lv_key_sql) = |{ ls_main-alias }~{ ls_key-fieldname }|.
      DATA(lv_current) = |{ concat_lines_of( table = lt_parts sep = `, ` ) } |.
      IF find( val = lv_current sub = |{ lv_key_sql } | ) < 0.
        APPEND |{ lv_key_sql } ASCENDING| TO lt_parts.
      ENDIF.
    ENDLOOP.

    rv_order = concat_lines_of( table = lt_parts sep = `, ` ).
  ENDMETHOD.

  METHOD to_literal.
    DATA(lv_value) = zcl_mcp_value=>to_internal( is_field    = is_res-field
                                                 iv_typename = is_res-typename
                                                 iv_value    = iv_value ).
    rv_literal = COND #( WHEN zcl_mcp_value=>is_numeric( is_res-field-inttype ) = abap_true
                         THEN lv_value                              " numbers are not quoted
                         ELSE cl_abap_dyn_prg=>quote( lv_value ) ).
  ENDMETHOD.

  METHOD check_mandatory.
    DATA lt_missing TYPE string_table.
    DATA lv_found   TYPE abap_bool.

    DATA(ls_main) = mt_sources[ 1 ].
    DATA(lt_required) = zcl_mcp_registry=>split_list( ls_main-reg-mandatory_filters ).

    LOOP AT lt_required INTO DATA(lv_req).
      lv_found = abap_false.
      LOOP AT it_filters INTO DATA(ls_filter).
        TRY.
            DATA(ls_res) = resolve_column( ls_filter-field ).
            IF ls_res-alias = ls_main-alias AND ls_res-field-fieldname = lv_req.
              lv_found = abap_true.
              EXIT.
            ENDIF.
          CATCH zcx_mcp_error.
            " reported later by build_where
        ENDTRY.
      ENDLOOP.
      IF lv_found = abap_false.
        APPEND lv_req TO lt_missing.
      ENDIF.
    ENDLOOP.

    IF lt_missing IS NOT INITIAL.
      RAISE EXCEPTION TYPE zcx_mcp_error
        EXPORTING iv_text = |Mandatory filter(s) missing for { ls_main-reg-obj_name }: | &&
                            |{ concat_lines_of( table = lt_missing sep = `, ` ) }.|.
    ENDIF.
  ENDMETHOD.

  METHOD check_authorization.
    DATA lt_conds TYPE string_table.

    LOOP AT mt_sources INTO DATA(ls_src).
      IF ls_src-reg-obj_type <> 'TABLE'.
        CONTINUE.                                   " CDS entities are protected by their DCL
      ENDIF.
      DATA(lv_tabname) = CONV tabname( ls_src-reg-obj_name ).
      CALL FUNCTION 'VIEW_AUTHORITY_CHECK'
        EXPORTING
          view_action                = 'S'
          view_name                  = lv_tabname
          no_warning_for_clientindep = abap_true
        EXCEPTIONS
          no_authority               = 1
          OTHERS                     = 2.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |No display authorization for table { lv_tabname } (S_TABU_DIS / S_TABU_NAM).|.
      ENDIF.

      DATA(lv_org) = zcl_mcp_org_auth=>get_condition( iv_alias = ls_src-alias it_fields = ls_src-fields ).
      IF lv_org IS NOT INITIAL.
        APPEND lv_org TO lt_conds.
      ENDIF.
    ENDLOOP.

    rv_where = concat_lines_of( table = lt_conds sep = ` AND ` ).
  ENDMETHOD.

  METHOD create_result_table.
    DATA lt_comp TYPE cl_abap_structdescr=>component_table.
    DATA lo_type TYPE REF TO cl_abap_typedescr.

    LOOP AT it_cols INTO DATA(ls_col).
      cl_abap_typedescr=>describe_by_name(
        EXPORTING  p_name         = ls_col-typename
        RECEIVING  p_descr_ref    = lo_type
        EXCEPTIONS type_not_found = 1
                   OTHERS         = 2 ).
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |Cannot resolve type { ls_col-typename }.|.
      ENDIF.
      APPEND VALUE #( name = ls_col-comp type = CAST cl_abap_datadescr( lo_type ) ) TO lt_comp.
    ENDLOOP.

    DATA(lo_struct) = cl_abap_structdescr=>create( lt_comp ).
    DATA(lo_table)  = cl_abap_tabledescr=>create( p_line_type = lo_struct ).
    CREATE DATA rr_table TYPE HANDLE lo_table.
  ENDMETHOD.

  METHOD effective_max_rows.
    rv_rows = COND #( WHEN is_reg-max_rows > 0 THEN is_reg-max_rows
                      ELSE zif_mcp_types=>c_default_max_rows ).
    rv_rows = nmin( val1 = rv_rows val2 = zif_mcp_types=>c_hard_max_rows ).
  ENDMETHOD.

ENDCLASS.
