"! Orchestrator for the four MCP tools. Parses the request body, picks the
"! handler by OBJ_TYPE, turns every error into a readable envelope and logs to SLG1.
CLASS zcl_mcp_gateway DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS list_objects
      IMPORTING iv_body        TYPE string
      RETURNING VALUE(rv_json) TYPE string.
    METHODS describe_object
      IMPORTING iv_body        TYPE string
      RETURNING VALUE(rv_json) TYPE string.
    METHODS query_data
      IMPORTING iv_body        TYPE string
      RETURNING VALUE(rv_json) TYPE string.
    METHODS call_function
      IMPORTING iv_body        TYPE string
      RETURNING VALUE(rv_json) TYPE string.
  PRIVATE SECTION.
    METHODS run
      IMPORTING iv_action      TYPE string
                iv_body        TYPE string
      RETURNING VALUE(rv_json) TYPE string.
    METHODS dispatch
      IMPORTING iv_action      TYPE string
                iv_body        TYPE string
      RETURNING VALUE(rv_json) TYPE string
      RAISING   zcx_mcp_error.
    METHODS do_list
      IMPORTING iv_body        TYPE string
      RETURNING VALUE(rv_json) TYPE string.
    METHODS get_handler
      IMPORTING is_reg            TYPE zmcp_registry
      RETURNING VALUE(ro_handler) TYPE REF TO zif_mcp_source_handler
      RAISING   zcx_mcp_error.
    METHODS write_log
      IMPORTING iv_action TYPE string
                iv_body   TYPE string
                iv_result TYPE string
                iv_ms     TYPE i.
ENDCLASS.

CLASS zcl_mcp_gateway IMPLEMENTATION.

  METHOD list_objects.
    rv_json = run( iv_action = `LIST` iv_body = iv_body ).
  ENDMETHOD.

  METHOD describe_object.
    rv_json = run( iv_action = `DESCRIBE` iv_body = iv_body ).
  ENDMETHOD.

  METHOD query_data.
    rv_json = run( iv_action = `QUERY` iv_body = iv_body ).
  ENDMETHOD.

  METHOD call_function.
    rv_json = run( iv_action = `CALL` iv_body = iv_body ).
  ENDMETHOD.

  METHOD run.
    DATA lv_start TYPE i.
    DATA lv_end   TYPE i.

    GET RUN TIME FIELD lv_start.
    TRY.
        rv_json = dispatch( iv_action = iv_action iv_body = iv_body ).
      CATCH zcx_mcp_error INTO DATA(lx_mcp).
        rv_json = zcl_mcp_envelope=>error( iv_message = lx_mcp->mv_text iv_action = iv_action ).
      CATCH cx_root INTO DATA(lx_root).
        rv_json = zcl_mcp_envelope=>error( iv_message = |Internal error: { lx_root->get_text( ) }|
                                           iv_action  = iv_action ).
    ENDTRY.
    GET RUN TIME FIELD lv_end.
    write_log( iv_action = iv_action iv_body = iv_body iv_result = rv_json iv_ms = ( lv_end - lv_start ) / 1000 ).
  ENDMETHOD.

  METHOD dispatch.
    DATA ls_reg   TYPE zmcp_registry.
    DATA ls_desc  TYPE zif_mcp_types=>ty_describe_args.
    DATA ls_query TYPE zif_mcp_types=>ty_query_args.
    DATA ls_call  TYPE zif_mcp_types=>ty_call_args.

    CASE iv_action.
      WHEN `LIST`.
        rv_json = do_list( iv_body ).

      WHEN `DESCRIBE`.
        /ui2/cl_json=>deserialize( EXPORTING json = iv_body pretty_name = /ui2/cl_json=>pretty_mode-camel_case
                                   CHANGING  data = ls_desc ).
        ls_reg  = zcl_mcp_registry=>get( ls_desc-obj_name ).
        rv_json = get_handler( ls_reg )->describe( ls_reg ).

      WHEN `QUERY`.
        /ui2/cl_json=>deserialize( EXPORTING json = iv_body pretty_name = /ui2/cl_json=>pretty_mode-camel_case
                                   CHANGING  data = ls_query ).
        ls_reg  = zcl_mcp_registry=>get( ls_query-obj_name ).
        rv_json = get_handler( ls_reg )->query( is_reg = ls_reg is_args = ls_query ).

      WHEN `CALL`.
        /ui2/cl_json=>deserialize( EXPORTING json = iv_body pretty_name = /ui2/cl_json=>pretty_mode-camel_case
                                   CHANGING  data = ls_call ).
        ls_reg  = zcl_mcp_registry=>get( ls_call-obj_name ).
        rv_json = get_handler( ls_reg )->execute(
                    is_reg         = ls_reg
                    iv_params_json = zcl_mcp_json=>extract_object( iv_json = iv_body iv_key = `params` ) ).
    ENDCASE.
  ENDMETHOD.

  METHOD do_list.
    DATA ls_args    TYPE zif_mcp_types=>ty_list_args.
    DATA lt_words   TYPE string_table.
    DATA lt_objects TYPE string_table.
    DATA lt_domains TYPE string_table.
    DATA lt_out     TYPE string_table.
    DATA lv_hit     TYPE abap_bool.

    IF iv_body IS NOT INITIAL.
      /ui2/cl_json=>deserialize( EXPORTING json = iv_body pretty_name = /ui2/cl_json=>pretty_mode-camel_case
                                 CHANGING  data = ls_args ).
    ENDIF.
    DATA(lv_domain) = to_upper( condense( ls_args-domain ) ).
    DATA(lv_search) = to_upper( condense( ls_args-search ) ).
    SPLIT lv_search AT space INTO TABLE lt_words.
    DELETE lt_words WHERE table_line IS INITIAL.

    DATA(lt_regs) = zcl_mcp_registry=>get_all_active( ).
    LOOP AT lt_regs INTO DATA(ls_reg).
      IF lv_domain IS NOT INITIAL
         AND ls_reg-domain <> lv_domain
         AND NOT ( ls_reg-obj_type = 'DOMAIN' AND ls_reg-obj_name = lv_domain ).
        CONTINUE.
      ENDIF.

      IF ls_reg-obj_type = 'DOMAIN'.
        APPEND zcl_mcp_json=>object( VALUE #(
          ( zcl_mcp_json=>pair( iv_key = `name`  iv_raw = zcl_mcp_json=>str( ls_reg-obj_name ) ) )
          ( zcl_mcp_json=>pair( iv_key = `rules` iv_raw = zcl_mcp_json=>str( ls_reg-description ) ) ) ) ) TO lt_domains.
        CONTINUE.
      ENDIF.

      IF lt_words IS NOT INITIAL.
        DATA(lv_text) = to_upper( |{ ls_reg-obj_name } { ls_reg-description }| ).
        lv_hit = abap_false.
        LOOP AT lt_words INTO DATA(lv_word).
          IF lv_text CS lv_word.
            lv_hit = abap_true.
            EXIT.
          ENDIF.
        ENDLOOP.
        IF lv_hit = abap_false.
          CONTINUE.
        ENDIF.
      ENDIF.

      APPEND zcl_mcp_json=>object( VALUE #(
        ( zcl_mcp_json=>pair( iv_key = `name`        iv_raw = zcl_mcp_json=>str( ls_reg-obj_name ) ) )
        ( zcl_mcp_json=>pair( iv_key = `type`        iv_raw = zcl_mcp_json=>str( ls_reg-obj_type ) ) )
        ( zcl_mcp_json=>pair( iv_key = `domain`      iv_raw = zcl_mcp_json=>str( ls_reg-domain ) ) )
        ( zcl_mcp_json=>pair( iv_key = `description` iv_raw = zcl_mcp_json=>str( ls_reg-description ) ) ) ) )
        TO lt_objects.
    ENDLOOP.

    APPEND zcl_mcp_json=>pair( iv_key = `status`  iv_raw = zcl_mcp_json=>str( `OK` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `action`  iv_raw = zcl_mcp_json=>str( `LIST` ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `objects` iv_raw = zcl_mcp_json=>array( lt_objects ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `domains` iv_raw = zcl_mcp_json=>array( lt_domains ) ) TO lt_out.
    APPEND zcl_mcp_json=>pair( iv_key = `message` iv_raw = zcl_mcp_json=>str(
      COND string( WHEN lt_objects IS INITIAL THEN `No matching objects. Try other keywords or omit search.`
                   ELSE `Next: call describeObject with objName before querying.` ) ) ) TO lt_out.
    rv_json = zcl_mcp_json=>object( lt_out ).
  ENDMETHOD.

  METHOD get_handler.
    CASE is_reg-obj_type.
      WHEN 'TABLE' OR 'CDS'.
        ro_handler = NEW zcl_mcp_table_handler( ).
      WHEN 'BAPI' OR 'FM'.
        ro_handler = NEW zcl_mcp_func_handler( ).
      WHEN 'ODATA'.
        ro_handler = NEW zcl_mcp_odata_handler( ).     " V2 itself, V4 via ZCL_MCP_ODATA_V4
      WHEN OTHERS.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |Object type { is_reg-obj_type } is not supported.|.
    ENDCASE.
  ENDMETHOD.

  METHOD write_log.
    DATA ls_log     TYPE bal_s_log.
    DATA lv_handle  TYPE balloghndl.
    DATA lt_handles TYPE bal_t_logh.
    DATA lv_text    TYPE c LENGTH 200.

    ls_log-object    = 'ZMCP'.
    ls_log-subobject = 'GATEWAY'.
    ls_log-extnumber = iv_action.
    ls_log-aluser    = sy-uname.
    ls_log-alprog    = sy-repid.
    CALL FUNCTION 'BAL_LOG_CREATE'
      EXPORTING  i_s_log      = ls_log
      IMPORTING  e_log_handle = lv_handle
      EXCEPTIONS OTHERS       = 1.
    IF sy-subrc <> 0.
      RETURN.                                       " log object not configured -> skip
    ENDIF.

    DATA(lv_is_error) = xsdbool( iv_result CS `"status":"ERROR"` ).
    DATA(lv_msgty) = COND symsgty( WHEN lv_is_error = abap_true THEN 'E' ELSE 'S' ).
    lv_text = |{ iv_action } { COND string( WHEN lv_is_error = abap_true THEN `ERROR` ELSE `OK` ) } { iv_ms } ms|.
    CALL FUNCTION 'BAL_LOG_MSG_ADD_FREE_TEXT'
      EXPORTING  i_log_handle = lv_handle
                 i_msgty      = lv_msgty
                 i_text       = lv_text
      EXCEPTIONS OTHERS       = 1.

    lv_text = iv_body.                              " first 200 characters of the request
    CALL FUNCTION 'BAL_LOG_MSG_ADD_FREE_TEXT'
      EXPORTING  i_log_handle = lv_handle
                 i_msgty      = 'I'
                 i_text       = lv_text
      EXCEPTIONS OTHERS       = 1.

    IF lv_is_error = abap_true.
      lv_text = iv_result.
      CALL FUNCTION 'BAL_LOG_MSG_ADD_FREE_TEXT'
        EXPORTING  i_log_handle = lv_handle
                   i_msgty      = 'E'
                   i_text       = lv_text
        EXCEPTIONS OTHERS       = 1.
    ENDIF.

    INSERT lv_handle INTO TABLE lt_handles.
    CALL FUNCTION 'BAL_DB_SAVE'
      EXPORTING  i_t_log_handle       = lt_handles
                 i_2th_connection     = abap_true
                 i_2th_connect_commit = abap_true
      EXCEPTIONS OTHERS               = 1.
  ENDMETHOD.

ENDCLASS.
