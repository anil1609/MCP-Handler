"! Row-level authorization for raw tables (ECC has no DCL).
"! For each org field present in a table (purch. org, plant, company code) the values
"! the user may display are determined once per request and added to the WHERE clause.
"! Adjust GET_RULES to your authorization concept (or move it to a customizing table).
CLASS zcl_mcp_org_auth DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    "! Returns e.g. "t0~EKORG IN ( '1000', '2000' )"; empty = no restriction needed
    CLASS-METHODS get_condition
      IMPORTING iv_alias        TYPE string
                it_fields       TYPE zif_mcp_types=>tt_dfies
      RETURNING VALUE(rv_where) TYPE string
      RAISING   zcx_mcp_error.
  PRIVATE SECTION.
    CONSTANTS c_max_list TYPE i VALUE 500.
    TYPES: BEGIN OF ty_rule,
             field       TYPE fieldname,
             value_table TYPE tabname,
             value_field TYPE fieldname,
             auth_object TYPE xuobject,
             auth_field  TYPE xufield,
           END OF ty_rule,
           tt_rule TYPE STANDARD TABLE OF ty_rule WITH EMPTY KEY.
    TYPES: BEGIN OF ty_allowed,
             field   TYPE fieldname,
             allowed TYPE string_table,
             denied  TYPE string_table,
           END OF ty_allowed.
    CLASS-DATA gt_allowed TYPE HASHED TABLE OF ty_allowed WITH UNIQUE KEY field.
    CLASS-METHODS get_rules
      RETURNING VALUE(rt_rules) TYPE tt_rule.
    CLASS-METHODS get_allowed
      IMPORTING is_rule           TYPE ty_rule
      RETURNING VALUE(rs_allowed) TYPE ty_allowed.
    CLASS-METHODS in_list
      IMPORTING it_values      TYPE string_table
      RETURNING VALUE(rv_list) TYPE string.
ENDCLASS.

CLASS zcl_mcp_org_auth IMPLEMENTATION.

  METHOD get_rules.
    rt_rules = VALUE #(
      ( field = 'EKORG' value_table = 'T024E' value_field = 'EKORG' auth_object = 'M_BEST_EKO' auth_field = 'EKORG' )
      ( field = 'WERKS' value_table = 'T001W' value_field = 'WERKS' auth_object = 'M_BEST_WRK' auth_field = 'WERKS' )
      ( field = 'BUKRS' value_table = 'T001'  value_field = 'BUKRS' auth_object = 'F_BKPF_BUK' auth_field = 'BUKRS' ) ).
  ENDMETHOD.

  METHOD get_condition.
    DATA lt_conds TYPE string_table.
    DATA(lt_rules) = get_rules( ).

    LOOP AT lt_rules INTO DATA(ls_rule).
      IF NOT line_exists( it_fields[ fieldname = ls_rule-field ] ).
        CONTINUE.
      ENDIF.
      DATA(ls_allowed) = get_allowed( ls_rule ).
      IF ls_allowed-denied IS INITIAL.
        CONTINUE.                                   " authorized for all values
      ENDIF.
      IF ls_allowed-allowed IS INITIAL.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |No display authorization ({ ls_rule-auth_object }) for any { ls_rule-field } value.|.
      ENDIF.

      DATA(lv_col) = |{ iv_alias }~{ ls_rule-field }|.
      IF lines( ls_allowed-allowed ) <= lines( ls_allowed-denied )
         AND lines( ls_allowed-allowed ) <= c_max_list.
        APPEND |{ lv_col } IN ( { in_list( ls_allowed-allowed ) } )| TO lt_conds.
      ELSEIF lines( ls_allowed-denied ) <= c_max_list.
        APPEND |{ lv_col } NOT IN ( { in_list( ls_allowed-denied ) } )| TO lt_conds.
      ELSE.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |Too many { ls_rule-field } values to authorize. Add a filter on { ls_rule-field }.|.
      ENDIF.
    ENDLOOP.

    rv_where = concat_lines_of( table = lt_conds sep = ` AND ` ).
  ENDMETHOD.

  METHOD get_allowed.
    TYPES ty_value TYPE c LENGTH 40.
    DATA lt_values TYPE STANDARD TABLE OF ty_value WITH EMPTY KEY.

    READ TABLE gt_allowed INTO rs_allowed WITH TABLE KEY field = is_rule-field.
    IF sy-subrc = 0.
      RETURN.
    ENDIF.

    rs_allowed-field = is_rule-field.
    DATA(lv_select) = CONV string( is_rule-value_field ).
    SELECT (lv_select) FROM (is_rule-value_table) INTO TABLE @lt_values.

    LOOP AT lt_values INTO DATA(lv_value).
      AUTHORITY-CHECK OBJECT is_rule-auth_object
        ID 'ACTVT'            FIELD '03'
        ID is_rule-auth_field FIELD lv_value.
      IF sy-subrc = 0.
        APPEND CONV string( lv_value ) TO rs_allowed-allowed.
      ELSE.
        APPEND CONV string( lv_value ) TO rs_allowed-denied.
      ENDIF.
    ENDLOOP.

    INSERT rs_allowed INTO TABLE gt_allowed.
  ENDMETHOD.

  METHOD in_list.
    DATA lt_lits TYPE string_table.
    LOOP AT it_values INTO DATA(lv_value).
      APPEND cl_abap_dyn_prg=>quote( lv_value ) TO lt_lits.
    ENDLOOP.
    rv_list = concat_lines_of( table = lt_lits sep = `, ` ).
  ENDMETHOD.

ENDCLASS.
