"! Converts a value sent by the LLM into the internal SAP format of a DDIC field:
"! ALPHA and other conversion exits (100045 -> 0000100045), NUMC padding (10 -> 00010),
"! dates (2026-10-01 -> 20261001), uppercase for non-lowercase fields, numeric validation.
"! Used by the table/CDS handler (SQL literals) and the OData V4 handler (range values).
CLASS zcl_mcp_value DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    CLASS-METHODS to_internal
      IMPORTING is_field        TYPE dfies
                iv_typename     TYPE string      " DDIC type of the field, e.g. EKKO-LIFNR
                iv_value        TYPE string
      RETURNING VALUE(rv_value) TYPE string
      RAISING   zcx_mcp_error.
    CLASS-METHODS is_numeric
      IMPORTING iv_inttype   TYPE inttype
      RETURNING VALUE(rv_ok) TYPE abap_bool.
ENDCLASS.

CLASS zcl_mcp_value IMPLEMENTATION.

  METHOD is_numeric.
    rv_ok = xsdbool( iv_inttype = 'I' OR iv_inttype = 'b' OR iv_inttype = 's' OR iv_inttype = '8'
                  OR iv_inttype = 'P' OR iv_inttype = 'F' OR iv_inttype = 'a' OR iv_inttype = 'e' ).
  ENDMETHOD.

  METHOD to_internal.
    DATA lr_typed TYPE REF TO data.
    FIELD-SYMBOLS <lv_typed> TYPE any.

    rv_value = shift_left( shift_right( iv_value ) ).

    IF is_numeric( is_field-inttype ) = abap_true.
      FIND REGEX '^-?\d+(\.\d+)?$' IN rv_value.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE zcx_mcp_error
          EXPORTING iv_text = |Value '{ iv_value }' is not numeric for field { is_field-fieldname }.|.
      ENDIF.
      RETURN.
    ENDIF.

    CASE is_field-inttype.
      WHEN 'D'.
        REPLACE ALL OCCURRENCES OF `-` IN rv_value WITH ``.
        IF rv_value IS INITIAL.
          rv_value = `00000000`.
        ELSEIF strlen( rv_value ) <> 8 OR rv_value CN '0123456789'.
          RAISE EXCEPTION TYPE zcx_mcp_error
            EXPORTING iv_text = |Date '{ iv_value }' for { is_field-fieldname } must be YYYY-MM-DD or YYYYMMDD.|.
        ENDIF.

      WHEN 'T'.
        REPLACE ALL OCCURRENCES OF `:` IN rv_value WITH ``.

      WHEN 'C' OR 'N'.
        IF is_field-lowercase IS INITIAL.
          rv_value = to_upper( rv_value ).
        ENDIF.
        IF is_field-convexit IS NOT INITIAL OR is_field-inttype = 'N'.
          TRY.
              CREATE DATA lr_typed TYPE (iv_typename).
              ASSIGN lr_typed->* TO <lv_typed>.
              IF is_field-convexit IS NOT INITIAL.
                DATA(lv_fm) = |CONVERSION_EXIT_{ is_field-convexit }_INPUT|.
                CALL FUNCTION lv_fm
                  EXPORTING  input  = rv_value
                  IMPORTING  output = <lv_typed>
                  EXCEPTIONS OTHERS = 1.
                IF sy-subrc <> 0.
                  <lv_typed> = rv_value.
                ENDIF.
              ELSE.
                <lv_typed> = rv_value.               " NUMC: right-aligned with leading zeros
              ENDIF.
              rv_value = <lv_typed>.
            CATCH cx_sy_create_data_error cx_sy_dyn_call_error cx_sy_conversion_error.
              " keep the value as sent
          ENDTRY.
        ENDIF.
    ENDCASE.
  ENDMETHOD.

ENDCLASS.
